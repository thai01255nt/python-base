# CDP

- ```docker build -t customer-data-platform:latest .```

- ```docker run -e FLASK_ENV=dev -p 5000:5000 -d customer-data-platform:latest```