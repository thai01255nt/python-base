from internal.src.http.handlers.configuration.generate import GenerateCreateDestinationController
from internal.app import api
from internal.db.psql import db
from internal.src.http.handlers.configuration.workspace import (
    WorkspaceController,
    WorkspaceGetController,
    WorkspaceGetAllMetaController
)
from internal.src.http.handlers.configuration.meta import (
    MetaController,
    MetaGetController,
    MetaGetAllFieldController
)
from internal.src.http.handlers.configuration.source import (
    SourceController,
    SourceGetController
)
from internal.src.http.handlers.configuration.destination import (
    DestinationController,
    DestinationGetController
)
from internal.src.http.handlers.configuration.import_mapping import (
    ImportMappingController,
    ImportMappingGetController
)
from internal.src.http.handlers.configuration.join_mapping import (
    JoinMappingController,
    JoinMappingGetController
)
from internal.src.http.handlers.configuration.user import (
    UserGetAllWorkspaceController
)

api.add_resource(UserGetAllWorkspaceController, '/users/<string:record_id>/workspaces')
api.add_resource(WorkspaceController, '/workspaces')
api.add_resource(WorkspaceGetController, '/workspaces/<string:record_id>')
api.add_resource(WorkspaceGetAllMetaController, '/workspaces/<string:record_id>/metas')

api.add_resource(MetaController, '/metas')
api.add_resource(MetaGetController, '/metas/<string:record_id>')
api.add_resource(MetaGetAllFieldController, '/metas/<string:record_id>/fields')

api.add_resource(SourceController, '/sources')
api.add_resource(SourceGetController, '/sources/<string:record_id>')

api.add_resource(DestinationController, '/destinations')
api.add_resource(DestinationGetController, '/destinations/<string:record_id>')

api.add_resource(ImportMappingController, '/import-mappings')
api.add_resource(ImportMappingGetController, '/import-mappings/<string:record_id>')

api.add_resource(JoinMappingController, '/join-mappings')
api.add_resource(JoinMappingGetController, '/join-mappings/<string:record_id>')

api.add_resource(GenerateCreateDestinationController, '/generates/create-destination/<string:meta_id>')

db.create_all()
db.session.commit()
