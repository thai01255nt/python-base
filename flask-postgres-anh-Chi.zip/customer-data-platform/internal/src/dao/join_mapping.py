from .base import BaseDAO
from internal.src.repositories.join_mapping import JoinMappingModel


class JoinMappingDAO(BaseDAO):
    def __init__(self):
        super().__init__(JoinMappingModel)
