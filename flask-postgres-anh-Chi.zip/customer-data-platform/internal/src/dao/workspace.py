from .base import BaseDAO
from internal.src.repositories.workspace import WorkspaceModel
from internal.db.psql import db


class WorkspaceDao(BaseDAO):
    def __init__(self):
        super().__init__(WorkspaceModel)

    def get_by_workspace_name_user_id(self, workspace_name, user_id):
        results = db.session.query(self.model).filter(
            db.and_(
                self.model.workspace_name == workspace_name,
                self.model.user_id == user_id,
                self.model.is_deleted == db.false()
            )
        ).all()
        return results

    def get_by_user_id(self, user_id):
        results = db.session.query(self.model).filter(
            db.and_(
                self.model.user_id == user_id,
                self.model.is_deleted == db.false()
            )
        ).all()
        return results
