from .base import BaseDAO
from internal.src.repositories.destination import DestinationModel
from internal.db.psql import db


class DestinationDAO(BaseDAO):
    def __init__(self):
        super().__init__(DestinationModel)

    def get_by_field_name_meta_id(self, field_name, meta_id):
        results = db.session.query(self.model).filter(
            db.and_(
                self.model.field_name == field_name,
                self.model.meta_id == meta_id,
                self.model.is_deleted == db.false()
            )
        ).all()
        return results
