from .base import BaseService
from internal.src.dao.join_mapping import JoinMappingDAO


class JoinMappingService(BaseService):
    def __init__(self):
        super().__init__(JoinMappingDAO())
