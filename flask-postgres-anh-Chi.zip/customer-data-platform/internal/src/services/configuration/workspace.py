from .base import BaseService
from internal.src.common.consts.message_consts import WorkspaceMessageConst
from internal.src.dao.workspace import WorkspaceDao
from internal.src.dao.meta import MetaDao
from internal.src.utils.data_utils import DataUtils
from internal.src.utils.postgres_utils import PostgresUtils
from internal.src.common.consts.response_consts import ResponseCode
from internal.src.services.exception.response_exception import ResponseException


class WorkspaceService(BaseService):
    def __init__(self):
        super().__init__(WorkspaceDao())
        self.meta_dao = MetaDao()

    def add(self, add_data):
        workspace_name = add_data['workspaceName']
        user_id = PostgresUtils.string_to_object_id(add_data['userId'])
        workspace_records = self.get_by_workspace_name_user_id(workspace_name=workspace_name, user_id=user_id)
        if len(workspace_records) > 0:
            raise ResponseException(ResponseCode.CONFLICT, message=WorkspaceMessageConst.WORKSPACE_NAME_EXISTS)
        record = self.dao.add(add_data)
        dict_data = DataUtils.record_to_dict(record)
        return dict_data

    def get_by_workspace_name_user_id(self, workspace_name, user_id, **kwargs):
        return DataUtils.records_to_dict(
            self.dao.get_by_workspace_name_user_id(workspace_name=workspace_name, user_id=user_id))

    def get_by_user_id(self, user_id, **kwargs):
        return DataUtils.records_to_dict(self.dao.get_by_user_id(user_id=user_id))

    def get_all_meta_by_workspace_id(self, workspace_id):
        workspace_record = self.dao.get(workspace_id)
        if workspace_record is None:
            raise ResponseException(ResponseCode.NOT_FOUND, message=WorkspaceMessageConst.WORKSPACE_ID_NOT_EXISTS)
        if workspace_record.is_deleted == True:
            raise ResponseException(ResponseCode.NOT_FOUND, message=WorkspaceMessageConst.WORKSPACE_ID_NOT_EXISTS)
        return DataUtils.records_to_dict(self.meta_dao.get_by_workspace_id(workspace_id))
