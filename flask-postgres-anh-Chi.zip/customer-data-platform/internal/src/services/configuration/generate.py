from ...common.consts.message_consts import (
    MetaMessageConst,
    GenerateMessageConst
)
from internal.src.common.consts.database_consts import MetaType
from internal.src.dao.raw import RawDAO
from internal.src.dao.meta import MetaDao
from internal.src.common.consts.response_consts import ResponseCode
from internal.src.services.exception.response_exception import ResponseException
from internal.src.utils.query_builder import generate_create_destination_query, create_table


class GenerateService():
    def __init__(self):
        self.meta_dao = MetaDao()
        self.raw_dao = RawDAO()

    def create_destination(self, meta_id):
        meta_record = self.meta_dao.get(meta_id)
        if meta_record is None:
            raise ResponseException(ResponseCode.NOT_FOUND, message=MetaMessageConst.META_ID_DESTINATION_NOT_EXISTS)
        elif meta_record.type != MetaType.DESTINATION or meta_record.is_deleted == True:
            raise ResponseException(ResponseCode.NOT_FOUND, message=MetaMessageConst.META_ID_DESTINATION_NOT_EXISTS)
        meta_info = self.raw_dao.get_for_create_destination(meta_id)
        sql_statement = generate_create_destination_query(meta_info)
        if sql_statement is None:
            raise ResponseException(ResponseCode.VALIDATION_FAILED,
                                    message=GenerateMessageConst.GENERATE_CREATE_DESTINATION_QUERY_FAIL)
        success = create_table(sql_statement)
        return success, sql_statement
