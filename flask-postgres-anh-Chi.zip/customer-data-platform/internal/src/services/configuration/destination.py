from .base import BaseService
from internal.src.common.consts.message_consts import (
    MetaMessageConst,
    DestinationMessageConst
)
from internal.src.dao.destination import DestinationDAO
from internal.src.dao.meta import MetaDao
from internal.src.utils.data_utils import DataUtils
from internal.src.utils.postgres_utils import PostgresUtils
from internal.src.services.exception.response_exception import ResponseException
from internal.src.common.consts.response_consts import ResponseCode
from internal.src.common.consts.database_consts import MetaType


class DestinationService(BaseService):
    def __init__(self):
        super().__init__(DestinationDAO())
        self.meta_dao = MetaDao()

    def add(self, add_data):
        meta_id = PostgresUtils.string_to_object_id(add_data['metaId'])
        field_name = add_data['fieldName']

        meta_record = self.meta_dao.get(meta_id)
        if meta_record is None:
            raise ResponseException(ResponseCode.NOT_FOUND,
                                    message=MetaMessageConst.META_ID_DESTINATION_NOT_EXISTS)
        elif meta_record.type != MetaType.DESTINATION or meta_record.is_deleted == True:
            raise ResponseException(ResponseCode.NOT_FOUND,
                                    message=MetaMessageConst.META_ID_DESTINATION_NOT_EXISTS)
        destination_records = self.dao.get_by_field_name_meta_id(field_name=field_name, meta_id=meta_id)
        if len(destination_records) > 0:
            raise ResponseException(ResponseCode.CONFLICT, message=DestinationMessageConst.DESTINATION_NAME_EXISTS)
        record = self.dao.add(add_data)
        dict_data = DataUtils.record_to_dict(record)
        return dict_data
