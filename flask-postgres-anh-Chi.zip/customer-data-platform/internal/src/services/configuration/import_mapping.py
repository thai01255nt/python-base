from .base import BaseService
from internal.src.utils.postgres_utils import PostgresUtils
from internal.src.utils.data_utils import DataUtils
from internal.src.dao.import_mapping import ImportMappingDao
from internal.src.dao.source import SourceDao
from internal.src.dao.destination import DestinationDAO
from internal.src.dao.meta import MetaDao
from internal.src.services.exception.error import ApiError
from internal.src.services.exception.response_exception import ResponseException
from internal.src.common.consts.response_consts import ResponseCode, LocationType
from internal.src.common.consts.message_consts import (
    SourceMessageConst,
    DestinationMessageConst,
    ImportMappingMessageConst
)


class ImportMappingService(BaseService):
    def __init__(self):
        super().__init__(ImportMappingDao())
        self.source_dao = SourceDao()
        self.destination_dao = DestinationDAO()
        self.meta_dao = MetaDao()

    def add(self, add_data):
        source_field_id = PostgresUtils.string_to_object_id(add_data['sourceFieldId'])
        destination_field_id = PostgresUtils.string_to_object_id(add_data['destinationFieldId'])
        source_record = self.source_dao.get(source_field_id)
        destination_record = self.destination_dao.get(destination_field_id)

        errors = []
        if source_record is None:
            errors.append(
                ApiError(code=ResponseCode.NOT_FOUND,
                         message=SourceMessageConst.SOURCE_ID_NOT_EXISTS,
                         location_type=LocationType.BODY,
                         location="/sourceFieldId")
            )
        elif source_record.is_deleted == True:
            errors.append(
                ApiError(code=ResponseCode.NOT_FOUND,
                         message=SourceMessageConst.SOURCE_ID_NOT_EXISTS,
                         location_type=LocationType.BODY,
                         location="/sourceFieldId")
            )
        if destination_record is None:
            errors.append(
                ApiError(code=ResponseCode.NOT_FOUND,
                         message=DestinationMessageConst.DESTINATION_ID_NOT_EXISTS,
                         location_type=LocationType.BODY,
                         location="/destinationFieldId")
            )
        elif destination_record.is_deleted == True:
            errors.append(
                ApiError(code=ResponseCode.NOT_FOUND,
                         message=DestinationMessageConst.DESTINATION_ID_NOT_EXISTS,
                         location_type=LocationType.BODY,
                         location="/destinationFieldId")
            )
        if len(errors) > 0:
            raise ResponseException(http_code=ResponseCode.NOT_FOUND, errors=errors)

        import_mapping_records = self.dao.get_by_source_field_id_destination_field_id(source_field_id=source_field_id,
                                                                                      destination_field_id=destination_field_id)
        if len(import_mapping_records) > 0:
            raise ResponseException(ResponseCode.CONFLICT, message=ImportMappingMessageConst.IMPORT_MAPPING_PAIR_EXISTS)
        record = self.dao.add(add_data)
        dict_data = DataUtils.record_to_dict(record)
        return dict_data

    # def get_full_import_mapping_by_source_meta_id(self, meta_id):
    #     meta_record = self.meta_dao.get(meta_id)
    #     errors = []
    #     if meta_record is None:
    #         errors.append(
    #             ApiError(code=ResponseCode.NOT_FOUND,
    #                      message=SourceMessageConst.SOURCE_ID_NOT_EXISTS,
    #                      location_type=LocationType.BODY,
    #                      location="/sourceFieldId")
    #         )
    #     elif meta_record.is_deleted == True or meta_record.type != MetaType.SOURCE:
    #         errors.append(
    #             ApiError(code=ResponseCode.NOT_FOUND,
    #                      message=SourceMessageConst.SOURCE_ID_NOT_EXISTS,
    #                      location_type=LocationType.BODY,
    #                      location="/sourceFieldId")
    #         )
    #     if len(errors) > 0:
    #         raise ResponseException(http_code=ResponseCode.NOT_FOUND, errors=errors)
    #
    #     field_records = self.meta_dao.get_all_fields_by_meta_record(meta_record=meta_record)
    #     if len(field_records) == 0:
    #         raise ResponseException(http_code=ResponseCode.CONFLICT, message=ImportMappingMessageConst.SOURCE_META_NOT_IMPORT_MAPPED)
