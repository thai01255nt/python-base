class FieldType:
    DICT = "dict"
    STRING = "string"
    NUMBER = "number"
    OID = "oid"
    SELECT = "select"
    LIST = "list"
    BOOL = "bool"


class MetaType:
    SOURCE = "S"
    DESTINATION = "D"
