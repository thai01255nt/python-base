class WorkspaceMessageConst:
    WORKSPACE_NAME_EXISTS = "Workspace name is already exists."
    WORKSPACE_ID_NOT_EXISTS = "Workspace id not exists or deleted."


class MetaMessageConst:
    META_NAME_EXISTS = "Meta name is already exists."
    META_ID_NOT_EXISTS = "Meta id not exists or deleted."
    META_ID_DESTINATION_NOT_EXISTS = "Destination meta id not exists or deleted."
    META_ID_SOURCE_NOT_EXISTS = "Source meta id not exists or deleted."


class DestinationMessageConst:
    DESTINATION_NAME_EXISTS = "Destination field name is already exists in this meta."
    DESTINATION_ID_NOT_EXISTS = "Destination field id not exists or deleted."


class SourceMessageConst:
    SOURCE_NAME_EXISTS = "Source field name is already exists in this meta."
    SOURCE_ID_NOT_EXISTS = "Source field id not exists or deleted."

class ImportMappingMessageConst:
    IMPORT_MAPPING_PAIR_EXISTS = "Import mapping pair is already exists."
    SOURCE_META_NOT_IMPORT_MAPPED= "Import mapping: source meta has no field in import mapping."

class JoinMappingMessageConst:
    JOIN_MAPPING_PAIR_EXISTS = "Import mapping pair is already exists."

class GenerateMessageConst:
    GENERATE_CREATE_DESTINATION_QUERY_FAIL = "Fail generate sql statement when create destination."
    CREATE_DESTINATION_FAIL = "Query create destination fail."
    CREATE_DESTINATION_SUCCESS = "Create destination success."
