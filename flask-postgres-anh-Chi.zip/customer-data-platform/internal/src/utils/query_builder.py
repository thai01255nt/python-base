import os
import psycopg2
from .config_utils import get_system_config
from ..dao.raw import RawDAO

env = os.getenv("FLASK_ENV")


class Meta:
    def __init__(self, fields):
        self.name = fields[0][0]
        self.fields = fields
        self.field_info = [field[1:] for field in fields]


def test_get_for_create_destination(meta_id):
    try:
        field_records = RawDAO().get_for_create_destination(meta_id)
        return field_records
    except Exception as error:
        print(error)
        return None


def parse_info_to_meta_object(info):
    try:
        table = Meta(info)
    except Exception as error:
        print(error)
        return None
    return table


def generate_create_destination_query(info):
    try:
        meta_object = parse_info_to_meta_object(info)
        fields_info = ''
        for field in meta_object.field_info:
            fields_info += f"\"{field[0]}\" {field[1]} {field[2] or ''}, "

        query = f"CREATE TABLE IF NOT EXISTS \"{meta_object.name}\"({fields_info[:-2]})"
    except Exception as error:
        print(error)
        return None
    return query


def create_table(query):
    conn = None
    try:
        params = get_system_config(env, sections=['transform'])['transform']
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute(query)
        cur.close()
        conn.commit()
        return True
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        return False
    finally:
        if conn is not None:
            conn.close()


if __name__ == '__main__':
    meta_info = test_get_for_create_destination('b634c069-6405-44f2-b2fe-3688e7287fec')
    query_generated = generate_create_destination_query(meta_info)
    create_table(query_generated)
