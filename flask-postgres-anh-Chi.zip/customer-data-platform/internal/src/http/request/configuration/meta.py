from validator import validate
from internal.src.http.request.custom_validator import CustomValidator


class AddMetaValidator:
    def __init__(self, data):
        self.data = data

    @staticmethod
    def __get_rules():
        rules = {
            'workspaceId': ['required', CustomValidator.ObjectId()],
            'metaName': 'required|string',
            'type': 'required|string'
        }
        return rules

    @staticmethod
    def validate(payload: dict):
        rules = AddMetaValidator.__get_rules()
        return validate(payload, rules, return_info=True)
