from validator import validate
from internal.src.http.request.custom_validator import CustomValidator


class AddImpportMappingValidator:
    def __init__(self, data):
        self.data = data

    @staticmethod
    def __get_rules():
        rules = {
            'sourceFieldId': ['required', CustomValidator.ObjectId()],
            'destinationFieldId': ['required', CustomValidator.ObjectId()]
        }
        return rules

    @staticmethod
    def validate(payload: dict):
        rules = AddImpportMappingValidator.__get_rules()
        return validate(payload, rules, return_info=True)
