from internal.src.services.configuration.destination import DestinationService
from internal.src.http.request.configuration.destination import AddDestinationValidator
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class DestinationController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = DestinationService()
        BasePostController.__init__(self, service, AddDestinationValidator)
        BaseGetAllController.__init__(self, service)


class DestinationGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(DestinationService())
