from internal.src.http.request.configuration.source import AddSourceValidator
from internal.src.services.configuration.source import SourceService
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class SourceController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = SourceService()
        BasePostController.__init__(self, service, AddSourceValidator)
        BaseGetAllController.__init__(self, service)


class SourceGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(SourceService())
