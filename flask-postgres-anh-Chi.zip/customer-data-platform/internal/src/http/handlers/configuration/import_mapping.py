from internal.src.services.configuration.import_mapping import ImportMappingService
from internal.src.http.request.configuration.import_mapping import AddImpportMappingValidator
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class ImportMappingController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = ImportMappingService()
        BasePostController.__init__(self, service, AddImpportMappingValidator)
        BaseGetAllController.__init__(self, service)


class ImportMappingGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(ImportMappingService())
