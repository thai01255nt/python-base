from internal.src.services.configuration.join_mapping import JoinMappingService
from internal.src.http.request.configuration.join_mapping import AddJoinMappingValidator
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class JoinMappingController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = JoinMappingService()
        BasePostController.__init__(self, service, AddJoinMappingValidator)
        BaseGetAllController.__init__(self, service)


class JoinMappingGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(JoinMappingService())
