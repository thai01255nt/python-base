from internal.src.http.request.configuration.meta import AddMetaValidator
from internal.src.services.configuration.meta import MetaService
from internal.src.middleware.common import valid_object_id_required
from internal.src.http.response.success import SuccessResponse
from internal.src.common.consts.response_consts import ResponseCode
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class MetaController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = MetaService()
        BasePostController.__init__(self, service, AddMetaValidator)
        BaseGetAllController.__init__(self, service)


class MetaGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(MetaService())


class MetaGetAllFieldController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(MetaService())

    @valid_object_id_required
    def get(self, record_id):
        datas = self.service.get_all_fields_by_meta_id(record_id)
        response_body = SuccessResponse(data=datas)
        return response_body, ResponseCode.OK
