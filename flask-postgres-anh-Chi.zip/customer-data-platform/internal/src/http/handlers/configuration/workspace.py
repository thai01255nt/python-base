from internal.src.http.response.success import SuccessResponse
from internal.src.common.consts.response_consts import ResponseCode
from internal.src.middleware.common import valid_object_id_required
from internal.src.services.configuration.workspace import WorkspaceService
from internal.src.http.request.configuration.workspace import AddWorkspaceValidator
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class WorkspaceController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = WorkspaceService()
        BasePostController.__init__(self, service, AddWorkspaceValidator)
        BaseGetAllController.__init__(self, service)


class WorkspaceGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(WorkspaceService())


class WorkspaceGetAllMetaController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(WorkspaceService())

    @valid_object_id_required
    def get(self, record_id):
        datas = self.service.get_all_meta_by_workspace_id(record_id)
        response_body = SuccessResponse(data=datas)
        return response_body, ResponseCode.OK
