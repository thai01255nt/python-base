import uuid
from sqlalchemy.dialects.postgresql import UUID

from internal.src.common.consts.database_consts import MetaType
from internal.db.psql import db


class MetaModel(db.Model):
    __tablename__ = 'meta'

    id = db.Column('id', UUID(as_uuid=True), default=uuid.uuid4, primary_key=True, unique=True)
    workspace_id = db.Column('workspaceId', UUID(as_uuid=True), db.ForeignKey('workspace.id'), nullable=False)
    meta_name = db.Column('metaName', db.String, nullable=False)
    type = db.Column('type', db.CHAR, nullable=False)
    is_deleted = db.Column('isDeleted', db.Boolean, nullable=False, default=False)
    # TODO changed this field to ENUM
    # kind = db.Column(db.String)

    __table_args__ = (
        db.Index(
            'uixWorkspaceIdTableNameMeta',
            'workspaceId',
            'metaName',
            unique=True,
            postgresql_where=(db.and_(is_deleted == db.false(), type == MetaType.DESTINATION))
        ),
    )

    def __init__(self, workspaceId, metaName, type):
        self.workspace_id = workspaceId
        self.meta_name = metaName
        self.type = type
    #
    # def add(self):
    #     db.session.add(self)
    #     db.session.commit()
    #     return self
    #
    # def update(self, id):
    #     raise Exception("Update method not implemented.")
    #
    # @staticmethod
    # def get(id):
    #     result = db.session.query(MetaModel).get(id)
    #     return result
    #
    # @staticmethod
    # def get_all():
    #     results = db.session.query(MetaModel).all()
    #     return results
