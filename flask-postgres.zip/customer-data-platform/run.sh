export FLASK_APP=configuration_app/route.py
export FLASK_ENV=dev
export FLASK_DEBUG=1
export PYTHONPATH=${PWD}
flask run --host='0.0.0.0'