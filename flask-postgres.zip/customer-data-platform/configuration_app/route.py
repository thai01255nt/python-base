from flask import make_response
from flask_restx import Api

from configuration_app.src.http.controller.workspace import (
    WorkspaceController,
    WorkspaceGetController,
    WorkspaceGetAllMetaController
)
from configuration_app.src.http.controller.meta import (
    MetaController,
    MetaGetController,
    MetaGetAllFieldController
)
from configuration_app.src.http.controller.source import (
    SourceController,
    SourceGetController
)
from configuration_app.src.http.controller.destination import (
    DestinationController,
    DestinationGetController
)
from configuration_app.src.http.controller.import_mapping import (
    ImportMappingController,
    ImportMappingGetController
)
from configuration_app.src.http.controller.join_mapping import (
    JoinMappingController,
    JoinMappingGetController
)
from configuration_app.src.http.controller.user import (
    UserGetAllWorkspaceController
)
from configuration_app.src.http.controller.generate import GenerateCreateDestinationController

from configuration_app.db.psql import db
from configuration_app.app import app
from configuration_app.src.utils.response_utils import ResponseUtils
from configuration_app.src.provider.exception.response_exception import ResponseException
from configuration_app.src.provider.exception.system_exception import SystemException
from configuration_app.src.http.response.base import BaseResponse

api = Api(app, prefix="/api.dev.setel.my/configurations/v1")


@api.representation('application/json')
def represent(data, code, headers=None):
    response_body = data
    if issubclass(data.__class__, BaseResponse):
        response_body = data.to_dict()
    resp = make_response(response_body, code)
    resp.headers.extend(headers or {})
    return resp


@api.errorhandler(ResponseException)
def handle_custom_exception(exception):
    return ResponseUtils.parse_response_from_exception(exception)


@api.errorhandler(SystemException)
def handle_custom_exception(exception):
    return ResponseUtils.parse_response_from_exception(exception)


@api.errorhandler(Exception)
def handle_custom_exception(exception):
    return ResponseUtils.parse_response_from_exception(exception)


api.add_resource(UserGetAllWorkspaceController, '/users/<string:record_id>/workspaces')
api.add_resource(WorkspaceController, '/workspaces')
api.add_resource(WorkspaceGetController, '/workspaces/<string:record_id>')
api.add_resource(WorkspaceGetAllMetaController, '/workspaces/<string:record_id>/metas')

api.add_resource(MetaController, '/metas')
api.add_resource(MetaGetController, '/metas/<string:record_id>')
api.add_resource(MetaGetAllFieldController, '/metas/<string:record_id>/fields')

api.add_resource(SourceController, '/sources')
api.add_resource(SourceGetController, '/sources/<string:record_id>')

api.add_resource(DestinationController, '/destinations')
api.add_resource(DestinationGetController, '/destinations/<string:record_id>')

api.add_resource(ImportMappingController, '/import-mappings')
api.add_resource(ImportMappingGetController, '/import-mappings/<string:record_id>')

api.add_resource(JoinMappingController, '/join-mappings')
api.add_resource(JoinMappingGetController, '/join-mappings/<string:record_id>')

api.add_resource(GenerateCreateDestinationController, '/generates/create-destination/<string:meta_id>')

db.create_all()
db.session.commit()
