import uuid
from ...common.consts.database_consts import FieldType
from .document_field import DocumentField

REQUEST_MODELS = {}

REQUEST_MODELS_WORKSPACE = {
    'workspaceName': DocumentField(field_type=FieldType.STRING, required=True),
    'userId': DocumentField(field_type=FieldType.OID, required=True),
}

REQUEST_MODELS_META = {
    'workspaceId': DocumentField(field_type=FieldType.OID, required=True),
    'metaName': DocumentField(field_type=FieldType.STRING, required=True),
    'type': DocumentField(field_type=FieldType.STRING, required=True),
}

REQUEST_MODELS_SOURCE = {
    'metaId': DocumentField(field_type=FieldType.OID, required=True),
    'fieldName': DocumentField(field_type=FieldType.STRING, required=True),
    'dataType': DocumentField(field_type=FieldType.STRING, required=True),
    'opt': DocumentField(field_type=FieldType.STRING, required=False),
}

REQUEST_MODELS_DESTINATION = {
    'metaId': DocumentField(field_type=FieldType.OID, required=True),
    'fieldName': DocumentField(field_type=FieldType.STRING, required=True),
    'dataType': DocumentField(field_type=FieldType.STRING, required=True),
    'opt': DocumentField(field_type=FieldType.STRING, required=False),
}

REQUEST_MODELS_IMPORT_MAPPING = {
    'sourceFieldId': DocumentField(field_type=FieldType.OID, required=True),
    'destinationFieldId': DocumentField(field_type=FieldType.OID, required=True),
}

REQUEST_MODELS_JOIN_MAPPING = {
    'parentFieldId': DocumentField(field_type=FieldType.OID, required=True),
    'childFieldId': DocumentField(field_type=FieldType.OID, required=True),
}
