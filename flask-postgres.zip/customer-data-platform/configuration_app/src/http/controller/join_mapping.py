from ...provider.service.join_mapping import JoinMappingService
from ..request.request_models import REQUEST_MODELS_JOIN_MAPPING
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class JoinMappingController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = JoinMappingService()
        BasePostController.__init__(self, service, REQUEST_MODELS_JOIN_MAPPING)
        BaseGetAllController.__init__(self, service)


class JoinMappingGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(JoinMappingService())
