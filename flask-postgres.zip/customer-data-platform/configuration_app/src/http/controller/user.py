from ..response.success import SuccessResponse
from ...common.consts.response_consts import ResponseCode
from ...provider.service.workspace import WorkspaceService
from ...middleware.common import valid_object_id_required
from .base import (
    BaseGetController,
)


class UserGetAllWorkspaceController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(WorkspaceService())

    @valid_object_id_required
    def get(self, record_id):
        data = self.service.get_by_user_id(record_id)
        response_body = SuccessResponse(data=data)
        return response_body, ResponseCode.OK
