from ..request.request_models import REQUEST_MODELS_META
from ...provider.service.meta import MetaService
from ...middleware.common import valid_object_id_required
from ..response.success import SuccessResponse
from ...common.consts.response_consts import ResponseCode
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class MetaController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = MetaService()
        BasePostController.__init__(self, service, REQUEST_MODELS_META)
        BaseGetAllController.__init__(self, service)


class MetaGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(MetaService())


class MetaGetAllFieldController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(MetaService())

    @valid_object_id_required
    def get(self, record_id):
        datas = self.service.get_all_fields_by_meta_id(record_id)
        response_body = SuccessResponse(data=datas)
        return response_body, ResponseCode.OK
