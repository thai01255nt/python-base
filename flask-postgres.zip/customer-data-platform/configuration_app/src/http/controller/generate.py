from flask_restful import Resource
from ...provider.service.generate import GenerateService
from ...middleware.common import valid_object_id_required
from ..response.success import SuccessResponse
from ..response.base import BaseResponse
from ...common.consts.response_consts import ResponseCode
from ...common.consts.message_consts import GenerateMessageConst


class GenerateCreateDestinationController(Resource):
    def __init__(self, *kwargs):
        self.service = GenerateService()

    @valid_object_id_required
    def post(self, meta_id):
        success, sql_statement = self.service.create_destination(meta_id)

        if success:
            data = {
                'sql_statement': sql_statement,
                'message': GenerateMessageConst.CREATE_DESTINATION_SUCCESS
            }
            response_body = SuccessResponse(message=data['message'], data=data)
            return response_body, ResponseCode.CREATED
        else:
            data = {
                'sql_statement': sql_statement,
                'message': GenerateMessageConst.CREATE_DESTINATION_FAIL
            }
            response_body = BaseResponse(message=data['message'], data=data)
            return response_body, ResponseCode.VALIDATION_FAILED
