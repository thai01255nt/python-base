from ..request.request_models import REQUEST_MODELS_WORKSPACE
from ..response.success import SuccessResponse
from ...common.consts.response_consts import ResponseCode
from ...middleware.common import valid_object_id_required
from ...provider.service.workspace import WorkspaceService
from ...provider.service.meta import MetaService
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class WorkspaceController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = WorkspaceService()
        BasePostController.__init__(self, service, REQUEST_MODELS_WORKSPACE)
        BaseGetAllController.__init__(self, service)


class WorkspaceGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(WorkspaceService())


class WorkspaceGetAllMetaController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(WorkspaceService())

    @valid_object_id_required
    def get(self, record_id):
        datas = self.service.get_all_meta_by_workspace_id(record_id)
        response_body = SuccessResponse(data=datas)
        return response_body, ResponseCode.OK
