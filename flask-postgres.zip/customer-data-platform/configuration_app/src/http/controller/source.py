from ..request.request_models import REQUEST_MODELS_SOURCE
from ...provider.service.source import SourceService
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class SourceController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = SourceService()
        BasePostController.__init__(self, service, REQUEST_MODELS_SOURCE)
        BaseGetAllController.__init__(self, service)


class SourceGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(SourceService())
