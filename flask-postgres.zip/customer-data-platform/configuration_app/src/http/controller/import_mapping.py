from ...provider.service.import_mapping import ImportMappingService
from ..request.request_models import REQUEST_MODELS_IMPORT_MAPPING
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class ImportMappingController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = ImportMappingService()
        BasePostController.__init__(self, service, REQUEST_MODELS_IMPORT_MAPPING)
        BaseGetAllController.__init__(self, service)


class ImportMappingGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(ImportMappingService())
