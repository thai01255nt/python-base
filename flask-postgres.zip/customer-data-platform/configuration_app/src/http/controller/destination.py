from ...provider.service.destination import DestinationService
from ..request.request_models import REQUEST_MODELS_DESTINATION
from .base import (
    BasePostController,
    BaseGetController,
    BaseGetAllController,
)


class DestinationController(BasePostController, BaseGetAllController):
    def __init__(self, *kwargs):
        service = DestinationService()
        BasePostController.__init__(self, service, REQUEST_MODELS_DESTINATION)
        BaseGetAllController.__init__(self, service)


class DestinationGetController(BaseGetController):
    def __init__(self, *kwargs):
        super().__init__(DestinationService())
