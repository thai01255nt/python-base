import uuid
from sqlalchemy.dialects.postgresql import UUID

from ...db.psql import db


class SourceModel(db.Model):
    __tablename__ = 'source'

    id = db.Column('id', UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True)
    meta_id = db.Column('metaId', UUID(as_uuid=True), db.ForeignKey('meta.id'), nullable=False)
    field_name = db.Column('fieldName', db.String, nullable=False)
    data_type = db.Column('dataType', db.String, nullable=False)
    opt = db.Column('opt', db.String, nullable=True)
    is_deleted = db.Column('isDeleted', db.Boolean, nullable=False, default=False)

    __table_args__ = (
        db.Index(
            'uixMetaIdFieldNameSource',
            'metaId',
            'fieldName',
            unique=True,
            postgresql_where=(is_deleted == db.false())
        ),
    )

    def __init__(self, metaId, fieldName, dataType, opt):
        self.meta_id = metaId
        self.field_name = fieldName
        self.data_type = dataType
        self.opt = opt

    def add(self):
        db.session.add(self)
        db.session.commit()
        return self

    def update(self, id):
        raise Exception("Update method not implemented.")

    @staticmethod
    def get(id):
        result = db.session.query(SourceModel).get(id)
        return result

    @staticmethod
    def get_all():
        results = db.session.query(SourceModel).all()
        return results
