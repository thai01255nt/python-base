import uuid
from sqlalchemy.dialects.postgresql import UUID

from ...db.psql import db


class WorkspaceModel(db.Model):
    __tablename__ = 'workspace'

    id = db.Column('id', UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True)
    workspace_name = db.Column('workspaceName', db.String, nullable=False)
    user_id = db.Column('userId', UUID(as_uuid=True), nullable=False)
    is_deleted = db.Column('isDeleted', db.Boolean, nullable=False, default=False)
    __table_args__ = (
        db.Index(
            'uixWorkspaceNameUserIdWorkspace',
            'workspaceName',
            'userId',
            unique=True,
            postgresql_where=(is_deleted == db.false())
        ),
    )

    def __init__(self, workspaceName, userId):
        self.workspace_name = workspaceName
        self.user_id = userId

    def add(self):
        db.session.add(self)
        db.session.commit()
        return self

    def update(self, id):
        raise Exception("Update method not implemented.")

    @staticmethod
    def get(id):
        result = db.session.query(WorkspaceModel).get(id)
        return result

    @staticmethod
    def get_all():
        results = db.session.query(WorkspaceModel).all()
        return results
