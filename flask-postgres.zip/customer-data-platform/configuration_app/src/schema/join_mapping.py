import uuid
from sqlalchemy.dialects.postgresql import UUID

from ...db.psql import db


class JoinMappingModel(db.Model):
    __tablename__ = 'joinMapping'

    id = db.Column('id', UUID(as_uuid=True), default=uuid.uuid4, primary_key=True, unique=True)
    parent_field_id = db.Column('parentFieldId', UUID(as_uuid=True), db.ForeignKey('destination.id'), nullable=False)
    child_field_id = db.Column('childFieldId', UUID(as_uuid=True), db.ForeignKey('destination.id'), nullable=False)
    is_deleted = db.Column('isDeleted', db.Boolean, nullable=False, default=False)

    __table_args__ = (
        db.Index(
            'uixParentFieldIdChildFieldIdJoinMapping',
            'parentFieldId',
            'childFieldId',
            unique=True,
            postgresql_where=(is_deleted == db.false())
        ),
    )

    # TODO: add more Constrains or Index only allow map source-destination fields in oneSource-oneDestination table

    def __init__(self, parentFieldId, childFieldId):
        self.parent_field_id = parentFieldId
        self.child_field_id = childFieldId

    def add(self):
        db.session.add(self)
        db.session.commit()
        return self

    def update(self, id):
        raise Exception("Update method not implemented.")

    @staticmethod
    def get(id):
        result = db.session.query(JoinMappingModel).get(id)
        return result

    @staticmethod
    def get_all():
        results = db.session.query(JoinMappingModel).all()
        return results
