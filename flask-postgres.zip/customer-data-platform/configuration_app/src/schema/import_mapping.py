import uuid
from sqlalchemy.dialects.postgresql import UUID

from ...db.psql import db


class ImportMappingModel(db.Model):
    __tablename__ = 'importMapping'

    id = db.Column('id', UUID(as_uuid=True), default=uuid.uuid4, primary_key=True, unique=True)
    source_field_id = db.Column('sourceFieldId', UUID(as_uuid=True), db.ForeignKey('source.id'), nullable=False)
    destination_field_id = db.Column('destinationFieldId', UUID(as_uuid=True), db.ForeignKey('destination.id'),
                                     nullable=False)
    is_deleted = db.Column('isDeleted', db.Boolean, nullable=False, default=False)

    __table_args__ = (
        db.Index(
            'uixSourceFieldDestinationFieldImportMapping',
            'sourceFieldId',
            'destinationFieldId',
            unique=True,
            postgresql_where=(is_deleted == db.false())
        ),
    )

    # TODO: add more Constrains or Index only allow map source-destination fields in oneSource-oneDestination table

    def __init__(self, sourceFieldId, destinationFieldId):
        self.source_field_id = sourceFieldId
        self.destination_field_id = destinationFieldId

    def add(self):
        db.session.add(self)
        db.session.commit()
        return self

    def update(self, id):
        raise Exception("Update method not implemented.")

    @staticmethod
    def get(id):
        result = db.session.query(ImportMappingModel).get(id)
        return result

    @staticmethod
    def get_all():
        results = db.session.query(ImportMappingModel).all()
        return results
