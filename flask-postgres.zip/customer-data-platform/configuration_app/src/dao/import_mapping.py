from .base import BaseDAO
from ..schema.import_mapping import ImportMappingModel
from ...db.psql import db


class ImportMappingDao(BaseDAO):
    def __init__(self):
        super().__init__(ImportMappingModel)

    def get_by_source_field_id_destination_field_id(self, source_field_id, destination_field_id):
        results = db.session.query(self.model).filter(
            db.and_(
                self.model.source_field_id == source_field_id,
                self.model.destination_field_id == destination_field_id,
                self.model.is_deleted == db.false()
            )
        ).all()
        return results
