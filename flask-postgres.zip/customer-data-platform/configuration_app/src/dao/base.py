class BaseDAO():
    def __init__(self, model):
        self.model = model

    def add(self, record):
        schema_object = self.model(**record)
        result = schema_object.add()
        return result

    def get(self, id):
        record = self.model.get(id)
        return record

    def get_all(self):
        records = self.model.get_all()
        return records
