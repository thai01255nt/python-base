from .base import BaseDAO
from ..schema.join_mapping import JoinMappingModel


class JoinMappingDAO(BaseDAO):
    def __init__(self):
        super().__init__(JoinMappingModel)
