from .base import BaseDAO
from ..schema.meta import MetaModel
from ..schema.source import SourceModel
from ..schema.destination import DestinationModel
from ..common.consts.database_consts import MetaType
from ...db.psql import db


class MetaDao(BaseDAO):
    def __init__(self):
        super().__init__(MetaModel)
        self.source_model = SourceModel
        self.destination_model = DestinationModel

    def get_by_workspace_id(self, workspace_id):
        results = db.session.query(self.model).filter(
            db.and_(
                self.model.workspace_id == workspace_id,
                self.model.is_deleted == db.false()
            )
        ).all()
        return results

    def get_all_fields_by_meta_record(self, meta_record):
        if meta_record.type == MetaType.SOURCE:
            results = db.session.query(self.source_model).filter(
                db.and_(
                    self.source_model.meta_id == meta_record.id,
                    self.source_model.is_deleted == db.false()
                )
            ).all()
        elif meta_record.type == MetaType.DESTINATION:
            results = db.session.query(self.destination_model).filter(
                db.and_(
                    self.destination_model.meta_id == meta_record.id,
                    self.destination_model.is_deleted == db.false()
                )
            ).all()
        else:
            results = []
        return results

    def get_meta_by_meta_name_workspace_id_type(self, meta_name, workspace_id, type):
        results = db.session.query(self.model).filter(
            db.and_(
                self.model.meta_name == meta_name,
                self.model.workspace_id == workspace_id,
                self.model.type == type,
                self.model.is_deleted == db.false()
            )
        ).all()
        return results
