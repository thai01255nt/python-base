from .base import BaseService
from ...common.consts.message_consts import (
    WorkspaceMessageConst,
    MetaMessageConst
)
from ...common.consts.database_consts import MetaType
from ...dao.meta import MetaDao
from ...dao.workspace import WorkspaceDao
from ...common.consts.response_consts import ResponseCode
from ...utils.data_utils import DataUtils
from ...utils.postgres_utils import PostgresUtils
from ..exception.response_exception import ResponseException


class MetaService(BaseService):
    def __init__(self):
        super().__init__(MetaDao())
        self.workspace_dao = WorkspaceDao()

    def add(self, add_data):
        meta_name = add_data['metaName']
        workspace_id = PostgresUtils.string_to_object_id(add_data['workspaceId'])
        type = add_data['type']
        workspace_record = self.workspace_dao.get(workspace_id)
        if workspace_record is None:
            raise ResponseException(ResponseCode.NOT_FOUND, message=WorkspaceMessageConst.WORKSPACE_ID_NOT_EXISTS)
        elif workspace_record.is_deleted == True:
            raise ResponseException(ResponseCode.NOT_FOUND, message=WorkspaceMessageConst.WORKSPACE_ID_NOT_EXISTS)
        if type == MetaType.DESTINATION:
            meta_records = self.dao.get_meta_by_meta_name_workspace_id_type(meta_name=meta_name,
                                                                            workspace_id=workspace_id,
                                                                            type=type)
            if len(meta_records) > 0:
                raise ResponseException(ResponseCode.CONFLICT, message=MetaMessageConst.META_NAME_EXISTS)
        record = self.dao.add(add_data)
        dict_data = DataUtils.record_to_dict(record)
        return dict_data

    def get_all_fields_by_meta_id(self, record_id):
        meta_record = self.dao.get(record_id)
        if meta_record is None:
            raise ResponseException(ResponseCode.NOT_FOUND, message=MetaMessageConst.META_ID_NOT_EXISTS)
        field_records = self.dao.get_all_fields_by_meta_record(meta_record)
        return DataUtils.records_to_dict(field_records)
