#!/bin/bash

export PIPELINEWISE_SOURCE="$PWD/pipelinewise-source"
export PIPELINEWISE_VIRTUALENV="$PIPELINEWISE_SOURCE/.virtualenvs"

BLUE_COLOR=$'\e[0;34m'
NO_COLOR=$'\e[0m'
log() {
  echo "${BLUE_COLOR}$1${NO_COLOR}"
}

# Run transfer_app
log "[INFO] [RUNNING] Run transfer_app"
#!/bin/bash
export PIPELINEWISE_HOME=$PIPELINEWISE_SOURCE

export FLASK_APP=transfer_app/src/app.py
export FLASK_ENV=dev
# export FLASK_DEBUG=1
export PYTHONPATH=${PYTHONPATH}:transfer_app/src
# active venv
source $PIPELINEWISE_VIRTUALENV/pipelinewise/bin/activate
flask run --host='0.0.0.0'
