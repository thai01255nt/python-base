# datalake-pipelinewise
## Introduction

## Docker

### Build and run from docker

- Build and tag this image:

```
docker build -t datalake-pipelinewise:latest .
```

- Run server on port 8000

```
(staging)

docker run --name datalake-pipelinewise -p 8001:80 -d datalake-pipelinewise:latest
```

### Build and run from source

- Setup
```
    chmod +x setup.sh
    ./setup.sh
```

- Runserver
```
    chmod +x run.sh
    ./run.sh
```

- Setup to use pipelinewise-source on terminal
```
    export PIPELINEWISE_HOME=$PWD/pipelinewise-source/
    source $PIPELINEWISE_HOME/.virtualenvs/pipelinewise/bin/activate
    
```