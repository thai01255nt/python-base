import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ELT_DIR = os.path.join(BASE_DIR, "transfer_app/public/elt")
if not os.path.exists(ELT_DIR):
    os.makedirs(ELT_DIR)
