#!/usr/bin/env bash
echo '~~~~~~ Starting build dev datalake-pipelinewise ~~~~~~~~~'

echo '~~~~~~ Starting build dockerfile ~~~~~~~~~~'
ENV=v1
HOST=registry.gitlab.com/setel/data
IMAGE=datalake-pipelinewise

cd ../ && docker build --cache-from=$HOST/$IMAGE:$ENV -t $HOST/$IMAGE:$ENV -f .docker/$ENV.dockerfile .

echo '~~~~~~ Ending build dockerfile ~~~~~~~~~~'
