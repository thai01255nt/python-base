#!/bin/bash

PIPELINEWISE_SOURCE="$PWD/pipelinewise-source"
PIPELINEWISE_VIRTUALENV="$PIPELINEWISE_SOURCE/.virtualenvs"

RED_COLOR=$'\e[1;31m'
BLUE_COLOR=$'\e[0;34m'
GREEN_COLOR=$'\e[0;32m'
NO_COLOR=$'\e[0m'

check_success() {
  if [ $2 != 0 ];then
    echo "${RED_COLOR}[INFO] [ERROR] $1 Fail.${NO_COLOR}"
    exit 1
  else
    echo "${GREEN_COLOR}[INFO] [SUCCESS] $1 Success.${NO_COLOR}"
  fi
}

log() {
  echo "${BLUE_COLOR}$1${NO_COLOR}"
}

log "[INFO] [INSTALL] Installing pipelinewise-source."
cd $PIPELINEWISE_SOURCE
apt-get update && apt-get install -y gettext-base
chmod +x install.sh && ./install.sh --connectors=tap-s3-csv,target-s3-csv --acceptlicenses
check_success "Installing pipelinewise-source" $?

cd ..

# install requirements.txt for transfer_app
log "[INFO] [INSTALL] Installing requirements.txt for transfer_app inside pipelinewise's virtualenv"
source $PIPELINEWISE_VIRTUALENV/pipelinewise/bin/activate
pip install -r requirements.txt
check_success "Installing requirements.txt" $?