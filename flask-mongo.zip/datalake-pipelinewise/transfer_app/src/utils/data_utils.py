import datetime
import os

from bson.objectid import ObjectId

TEXT_MAX_BYTE = 1024


class DataUtils:
    @staticmethod
    def is_dict_type(value):
        return type(value) is dict

    @staticmethod
    def is_has_value(value):
        return value is not None and str(value).strip() != ""

    @staticmethod
    def is_valid_common_number(value):
        try:
            return pow(-2, 31) < int(value) < pow(2, 31) - 1
        except Exception:
            return False

    @staticmethod
    def is_valid_common_string(value):
        value_length = len(value.encode("utf-8"))
        return value_length <= TEXT_MAX_BYTE

    @staticmethod
    def mongo_schema_to_dict(document, ignore_fields=["password"]):
        document_dict = document.to_mongo().to_dict()
        result = DataUtils.mongo_dict_to_dict(document_dict, ignore_fields=ignore_fields)
        return result

    @staticmethod
    def mongo_cursor_to_dicts(documents, ignore_fields=["password"]):
        result = []
        for document in documents:
            element = DataUtils.mongo_dict_to_dict(document, ignore_fields=ignore_fields)
            result.append(element)
        return result

    @staticmethod
    def mongo_dict_to_dict(document, ignore_fields=["password"]):
        result = {}
        for field_name, field_value in document.items():
            if field_name in ignore_fields:
                continue
            if field_name == "_id":
                result["_id"] = str(field_value)
            elif isinstance(field_value, ObjectId):
                result[field_name] = str(field_value)
            elif isinstance(field_value, dict):
                result[field_name] = DataUtils.mongo_dict_to_dict(field_value)
            elif isinstance(field_value, datetime.date):
                result[field_name] = field_value.isoformat()
            else:
                result[field_name] = field_value
        return result

    @staticmethod
    def get_value_from_dict_by_key(object_data, key):
        result = object_data[key] if key in object_data else None
        return result

    # @staticmethod
    # def get_value_from_request_args_by_key(request_args, key):
    #     result = request_args.get(key) if key in request_args else None
    #     return result

    @staticmethod
    def get_file_extension_from_file_name(file_name):
        return os.path.splitext(file_name)[1][1:]

    # @staticmethod
    # def random_string(length=6):
    #     result = "".join(
    #         [random.choice(string.ascii_uppercase) for i in range(length)])
    #     return result

    @staticmethod
    def count_condition_docs(documents, pre_condition:dict={},**conditions):
        '''
        This function return total satisfy pre-condition doc and condition_doc which
        satisfy condition.
        NOTE: not work with dept object
        '''

        total_docs = len(documents)
        condition_docs = 0

        for document in documents:
            condition_docs += 1 # automatic count 1 doc
            document_dict = DataUtils.mongo_schema_to_dict(document)

            # check pre-condition to discard document
            for k,v in pre_condition.items(): # if doc does not satisfy condition, reduce 1
                try:
                    if document_dict[k] != v:
                        total_docs -= 1
                        condition_docs -= 1
                        break
                except Exception as e:
                    total_docs -= 1
                    condition_docs -= 1
                    break

            # if doc does not satisfy condition, reduce condition_docs by 1
            for k,v in conditions.items():
                try:
                    if document_dict[k] != v:
                        condition_docs -= 1
                        break
                except Exception as e:
                    condition_docs -= 1
                    break
        return total_docs ,condition_docs
