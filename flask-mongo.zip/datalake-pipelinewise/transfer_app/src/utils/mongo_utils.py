from bson.objectid import ObjectId
from flask import current_app as app


class MongoUtils:
    @staticmethod
    def get_record_from_collection_by_id(record_id, collection_name):
        db_config = app.config["SYS"]["db"]
        if not ObjectId.is_valid(record_id):
            return None
        record = app.db[db_config["name"]][collection_name].find_one(
            {"_id": ObjectId(record_id)}
        )
        return record

    @staticmethod
    def is_valid_object_id(value):
        return ObjectId.is_valid(value)

    @staticmethod
    def string_to_object_id(value):
        if not MongoUtils.is_valid_object_id(value):
            raise Exception("Invalid object id")
        return ObjectId(value)

    @staticmethod
    def generate_params_connection(config_db: dict) -> dict:
        connection_params_db = {
            "db": config_db["db_name"],
            "host": config_db["host"],
            "port": int(config_db["port"]),
            "username": config_db["username"],
            "password": config_db["password"],
            "authentication_source": config_db["authentication_source"],
            "ssl": config_db.get("ssl", True),
            "replicaSet": config_db.get("replica_set", None),
        }
        return connection_params_db

    @staticmethod
    def generate_uri(config_db: dict) -> str:
        config_host = config_db["host"]
        if type(config_host) is str:
            host = config_host
        else:
            host = ""
            for _host in config_host:
                host += _host + ","
            host = host[:-1]

        ssl = config_db.get("ssl", "true")
        db_name = config_db["db_name"]
        db_uri_default = "mongodb+srv://<username>:<password>@<host>/<db_name>?retryWrites=true&w=majority&ssl=<ssl>"
        db_uri_default = db_uri_default.replace("<username>", config_db["username"])
        db_uri_default = db_uri_default.replace("<password>", config_db["password"])
        db_uri_default = db_uri_default.replace("<host>", host)
        db_uri_default = db_uri_default.replace("<db_name>", db_name)
        db_uri_default = db_uri_default.replace("<ssl>", ssl)
        return db_uri_default
