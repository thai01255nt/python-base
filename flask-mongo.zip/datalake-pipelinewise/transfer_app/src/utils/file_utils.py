# utils for working with file
import json
import os
import uuid


class FileUtil:
    @staticmethod
    def generate_uuid_file(base_dir: str):
        # check for exited base file
        if not os.path.isdir(base_dir):
            return None

        # generate new working dir
        filename = uuid.uuid4().hex
        return os.path.join(base_dir, filename)

    @staticmethod
    def create_json_file(json_content: dict, file_name: str, work_dir: str):
        # generate file
        try:
            # create parent directory
            if not os.path.exists(work_dir):
                os.mkdir(work_dir)

            # write json to file
            with open(os.path.join(work_dir, file_name + ".json"), "w") as json_file:
                json.dump(json_content, json_file)

            # if succesffully, return None
            return None
        except Exception as e:
            return e
