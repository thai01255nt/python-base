from ..commons.models.responses.base_response import BaseResponse


class ResponseUtils:
    @staticmethod
    def parse_response_from_response_exception(exception):
        http_code = exception.http_code
        body_code = exception.body_code
        message = exception.message
        errors = exception.errors

        response_body = BaseResponse(code=body_code, message=message, errors=errors).to_dict()
        return response_body, http_code
