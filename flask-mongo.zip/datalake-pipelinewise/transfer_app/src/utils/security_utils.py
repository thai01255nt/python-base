import os, json, base64
from cryptography.fernet import Fernet


fixed_key = "3i-mlomKCdpiDUeI3OoRgA1s9a8-SNo0F60kqykSIg0="


class CryptoUtil():

    # encrypt function
    @staticmethod
    def encrypt_json_to_string(json_dict: dict, key:str=None):
        # build cryptopher
        key = key if key else fixed_key
        cryptopher = Fernet(key.encode())

        # encrypt phrase
        string = json.dumps(json_dict)
        byte_string = string.encode()
        encrypted_message = cryptopher.encrypt(byte_string)

        # apply b64 to convert back to text
        b64_bytes = base64.b64encode(encrypted_message)
        b64_string = b64_bytes.decode()

        # return
        return b64_string

    @staticmethod
    def decrypt_string_to_json(string: str, key:str=None):
        # build cryptopher
        key = key if key else fixed_key
        cryptopher = Fernet(key.encode())

        # decode b64 text
        b64_bytes = string.encode()
        encrypted_message = base64.b64decode(b64_bytes)

        # decrypt string
        text = cryptopher.decrypt(encrypted_message)
        text = text.decode()
        decrypt_dict = json.loads(text)

        # return
        return decrypt_dict

    

