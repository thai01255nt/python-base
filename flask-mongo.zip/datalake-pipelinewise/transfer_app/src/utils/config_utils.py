import json


def get_system_config(env):
    env_name = env if env else "dev"
    with open(f"./transfer_app/configs/{env_name}.json") as json_data_file:
        data = json.load(json_data_file)
    return data
