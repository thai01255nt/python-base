import os

from transfer_app.src.commons.consts.response_consts import ResponseCode
from transfer_app.src.commons.consts.transfer_consts import TransferFileName
from transfer_app.src.commons.errors.response_exception import ResponseException
from transfer_app.src.commons.models.responses.api_error import ApiError
from transfer_app.src.utils.data_utils import DataUtils
from transfer_app.src.utils.security_utils import CryptoUtil # NOTE: default data stored in mongo is encrypted
from .base_utils import BaseUtils



class TransferUtils:
    @staticmethod
    def save_json_from_dict(elt_dict, nullable=True, ignore_field_check_null=["state"]):
        # check null values
        tap_id = elt_dict["tapId"]
        target_id = elt_dict["targetId"]
        elt_id = elt_dict["_id"]
        config_dir = BaseUtils.get_config_dir(elt_id)
        field_to_filename = BaseUtils.generate_field_mapping_filename(
            tap_id=tap_id,
            target_id=target_id,
            config_dir=config_dir
        )
        for field in field_to_filename.keys():
            if (elt_dict[field] is None or elt_dict[field] == {}) and field not in ignore_field_check_null:
                if not nullable:
                    BaseUtils.delete_config_dir(config_dir)
                    raise Exception("You need import before run transfer")
            else:
                dirname = os.path.dirname(field_to_filename[field])
                if not os.path.exists(dirname):
                    os.makedirs(dirname)
                BaseUtils.generate_dict_to_json(elt_dict[field], des=field_to_filename[field])
        return

    @staticmethod
    def import_project_from_dict(tap_config_dict, target_config_dict, elt_id):
        config_dir = BaseUtils.get_config_dir(elt_id)
        yaml_folder = os.path.join(config_dir, TransferFileName.YAML_FOLDER)
        des_tap_yaml = os.path.join(yaml_folder, TransferFileName.TAP_YAML_FILENAME)
        des_target_yaml = os.path.join(yaml_folder, TransferFileName.TARGET_YAML_FILENAME)
        try:
            BaseUtils.generate_dict_to_yaml(tap_config_dict, des_tap_yaml)
        except Exception:
            BaseUtils.delete_config_dir(config_dir)
            raise Exception(f'{"generate_dict_to_yml for tap fail"}')
        try:
            BaseUtils.generate_dict_to_yaml(target_config_dict, des_target_yaml)
        except Exception:
            BaseUtils.delete_config_dir(config_dir)
            raise Exception(f'{"generate_dict_to_yml for target fail"}')
        import_command = (
            f"{BaseUtils.PREFIX_TRANSFER_CLI_COMMAND} import --dir {yaml_folder} --config_dir {config_dir}"
        )
        try_catch_command = BaseUtils.generate_try_catch_cli(
            command=import_command,
            tap_id=tap_config_dict["id"],
            target_id=target_config_dict["id"],
            elt_id=elt_id,
            config_dir=config_dir,
        )
        BaseUtils.run_nowait(cmd=try_catch_command)
        return

    @staticmethod
    def import_project_from_record(tap_record, target_record, elt_record):
        # decrypt record config
        if tap_record.config:
            tap_record.config = CryptoUtil.decrypt_string_to_json(tap_record.config['encrypted_config'])
        
        if target_record.config:
            target_record.config = CryptoUtil.decrypt_string_to_json(target_record.config['encrypted_config'])

        elt_dict = DataUtils.mongo_schema_to_dict(elt_record)
        elt_id = elt_dict["_id"]
        BaseUtils.generate_config_dir(elt_id)
        TransferUtils.save_json_from_dict(elt_dict)

        tap_config_dict = DataUtils.mongo_schema_to_dict(tap_record)["config"]
        target_config_dict = DataUtils.mongo_schema_to_dict(target_record)["config"]
        tap_config_dict["id"] = str(tap_record.id)
        target_config_dict["id"] = str(target_record.id)
        tap_config_dict["target"] = target_config_dict["id"]
        TransferUtils.import_project_from_dict(
            tap_config_dict,
            target_config_dict,
            elt_id
        )
        return

    @staticmethod
    def run_elt_from_record(elt_record):
        # decrypt elt config
        if elt_record.tapConfig:
            elt_record.tapConfig = CryptoUtil.decrypt_string_to_json(elt_record.tapConfig['encrypted_config'])
        
        if elt_record.targetConfig:
            elt_record.targetConfig = CryptoUtil.decrypt_string_to_json(elt_record.targetConfig['encrypted_config'])

        elt_dict = DataUtils.mongo_schema_to_dict(elt_record)
        tap_id = elt_dict["tapId"]
        target_id = elt_dict["targetId"]
        elt_id = elt_dict["_id"]

        try:
            config_dir = BaseUtils.generate_config_dir(elt_id)
        except Exception as e:
            errors = [ApiError(message=str(e), code=ResponseCode.INTERNAL_SERVER_ERROR)]
            raise ResponseException(http_code=ResponseCode.INTERNAL_SERVER_ERROR, errors=errors)
        try:
            TransferUtils.save_json_from_dict(elt_dict, nullable=False)
        except Exception as e:
            BaseUtils.delete_config_dir(elt_record)
            errors = [
                ApiError(
                    message=str(f'{"Run transfer fail with message: "}' + str(e)),
                    code=ResponseCode.BAD_REQUEST,
                )
            ]
            raise ResponseException(http_code=ResponseCode.BAD_REQUEST, errors=errors)

        run_tap_command = (
            f"{BaseUtils.PREFIX_TRANSFER_CLI_COMMAND}"
            f" run_tap --tap {tap_id} --target {target_id} --config_dir {config_dir}"
        )
        try_catch_command = BaseUtils.generate_try_catch_cli(
            command=run_tap_command,
            tap_id=tap_id,
            target_id=target_id,
            elt_id=elt_id,
            config_dir=config_dir,
        )
        BaseUtils.run_nowait(cmd=try_catch_command)
        return
