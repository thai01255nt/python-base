from transfer_app.src.utils.data_utils import DataUtils
from transfer_app.src.utils.mongo_utils import MongoUtils

from .base_utils import BaseUtils


class UpdateHistoryUtils:
    @staticmethod
    def update_elt_history(elt_id, update_history_data, dao_elt, dao_history):
        elt_record = dao_elt.get_record_by_id(elt_id)
        elt_dict = DataUtils.mongo_schema_to_dict(elt_record)
        tap_id = elt_dict["tapId"]
        target_id = elt_dict["targetId"]

        last_history_id = elt_dict["lastHistory"]["_id"]
        history_record = dao_history.get_record_by_id(MongoUtils.string_to_object_id(last_history_id))
        updated_history_record = dao_history.update_record_by_id(history_record.id, update_history_data)

        config_dir = BaseUtils.get_config_dir(elt_id)
        if update_history_data["retCode"] != 0:
            update_data = {}
            update_data["lastHistory"] = DataUtils.mongo_schema_to_dict(
                updated_history_record, ignore_fields=["createdAt", "updatedAt"]
            )
            update_data["eltStatus"] = update_data["lastHistory"]["eltStatus"]
            dao_elt.update_record_by_id(elt_record.id, update_data=update_data)
        else:
            update_data = {}
            field_to_filename = BaseUtils.generate_field_mapping_filename(tap_id, target_id, config_dir)
            for field in field_to_filename:
                if field != "state":
                    update_data[field] = BaseUtils.load_json(field_to_filename[field])
                else:
                    try:
                        update_data[field] = BaseUtils.load_json(field_to_filename[field])
                    except Exception:
                        update_data[field] = None
            update_data["lastHistory"] = DataUtils.mongo_schema_to_dict(
                updated_history_record, ignore_fields=["createdAt", "updatedAt"]
            )
            update_data["eltStatus"] = update_data["lastHistory"]["eltStatus"]
            dao_elt.update_record_by_id(record_id=elt_record.id, update_data=update_data)
        return
