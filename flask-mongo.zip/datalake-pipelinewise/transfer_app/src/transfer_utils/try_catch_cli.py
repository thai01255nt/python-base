import datetime
import os
import glob
import argparse
from mongoengine import connect
from pipelinewise.cli.pipelinewise import PipelineWise
from transfer_app.src.commons.consts.database_consts import DbAliasType
from transfer_app.src.commons.consts.transfer_consts import TransferStatusType
from transfer_app.src.daos.transfer_dao import DAOELT, DAOHistory
from transfer_app.src.transfer_utils.base_utils import BaseUtils
from transfer_app.src.transfer_utils.update_history_utils import UpdateHistoryUtils
from transfer_app.src.utils.config_utils import get_system_config
from transfer_app.src.utils.mongo_utils import MongoUtils

if __name__ == "__main__":
    start_time = datetime.datetime.now()
    parser = argparse.ArgumentParser(add_help=True, )
    parser.add_argument("--command", type=str, default=None, required=False, help='"command')
    parser.add_argument("--tap_id", type=str, default=None, required=False, help='"tap_id')
    parser.add_argument("--target_id", type=str, default=None, required=False, help='"target_id')
    parser.add_argument("--elt_id", type=str, default=None, required=False, help='"elt_id')
    parser.add_argument("--config_dir", type=str, default=None, required=False, help='"config_dir')

    args = parser.parse_args()

    command = eval(args.command)
    tap_id = args.tap_id
    target_id = args.target_id
    elt_id = args.elt_id
    config_dir = args.config_dir

    ret_code, log_message, proc = BaseUtils.run_wait(cmd=command)
    # Using log file of pipelinewise if it's exists
    ppw_instance = PipelineWise.__new__(PipelineWise)
    ppw_instance.config_dir = config_dir
    tap_log_dir = ppw_instance.get_tap_log_dir(target_id=target_id, tap_id=tap_id)
    tap_log_files = glob.glob(os.path.join(tap_log_dir, "*"))
    if len(tap_log_files) > 0:
        tap_log_files.sort()
        tap_log_file = tap_log_files[-1]
        with open(tap_log_file, "r") as f:
            log_message = f.read()

    update_history_data = {
        "eltStatus": TransferStatusType.STOPPED,
        "retCode": ret_code,
        "logMessage": log_message,
        "duration": str(datetime.datetime.now() - start_time),
    }

    env = os.getenv("FLASK_ENV")
    config_data = get_system_config(env)
    config_db = config_data.get("db")
    connection_params_db = MongoUtils.generate_params_connection(config_db)
    db = connect(alias=DbAliasType.TRANSFER_DB_ALIAS, **connection_params_db)

    dao_history = DAOHistory()
    dao_elt = DAOELT()
    # TODO not sure stable of that DAO
    try:
        UpdateHistoryUtils.update_elt_history(elt_id, update_history_data, dao_elt, dao_history)
    except Exception as error:
        BaseUtils.delete_config_dir(config_dir)
        raise Exception(error)
    BaseUtils.delete_config_dir(config_dir)
