import json
import os
import subprocess

import yaml

import settings
from transfer_app.src.commons.consts.transfer_consts import TransferFileName

TRANSFER_UTILS_FOLDER = os.path.dirname(os.path.abspath(__file__))
TRANSFER_CLI_PYTHON_FILE = os.path.join(TRANSFER_UTILS_FOLDER, "vmo_pipelinewise.py")
TRY_CATCH_CLI_PYTHON_FILE = os.path.join(TRANSFER_UTILS_FOLDER, "try_catch_cli.py")


class BaseUtils:
    PREFIX_TRANSFER_CLI_COMMAND = f"python {TRANSFER_CLI_PYTHON_FILE}"

    @staticmethod
    def generate_try_catch_cli(command, tap_id, target_id, elt_id, config_dir):
        return [
            "python", TRY_CATCH_CLI_PYTHON_FILE, "--command", str(command.split(" ")),
            "--tap_id", tap_id, "--target_id", target_id, "--elt_id", elt_id, "--config_dir", config_dir,
        ]

    @staticmethod
    def load_json(path):
        with open(path, "r") as f:
            data = json.load(f)
        return data

    @staticmethod
    def get_config_dir(id):
        return os.path.join(settings.ELT_DIR, id)

    @staticmethod
    def generate_config_dir(elt_id):
        config_dir = BaseUtils.get_config_dir(elt_id)
        if os.path.exists(config_dir):
            try:
                BaseUtils.delete_config_dir(config_dir)
            except Exception:
                raise Exception(f"Can't remove already exists config_dir folder {elt_id}")
        try:
            os.mkdir(config_dir)
        except Exception:
            raise Exception(f"Can't create config_dir folder for elt id {elt_id}")
        return config_dir

    @staticmethod
    def delete_config_dir(config_dir):
        os.system(f'rm -rf "{config_dir}"')

    @staticmethod
    def run_wait(cmd, cwd=None):
        proc = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        ret_code = proc.wait()
        output, error = proc.communicate()
        log_message = ""
        if output != b"":
            log_message += output.decode() + "\n"
        if error != b"":
            log_message += error.decode() + "\n"
        proc.kill()
        return ret_code, log_message, proc

    @staticmethod
    def run_nowait(cmd, cwd=None):
        proc = subprocess.Popen(cmd, cwd=cwd)
        return None, None, proc

    @staticmethod
    def generate_field_mapping_filename(tap_id, target_id, config_dir):
        mapping = {
            "globalConfig": os.path.join(config_dir, TransferFileName.GLOBAL_CONFIG_FILENAME),
            "tapConfig": os.path.join(config_dir, target_id, tap_id, TransferFileName.TAP_CONFIG_FILENAME),
            "targetConfig": os.path.join(config_dir, target_id, TransferFileName.TARGET_CONFIG_FILENAME),
            "inheritableConfig": os.path.join(
                config_dir,
                target_id,
                tap_id,
                TransferFileName.INHERITABLE_CONFIG_FILENAME,
            ),
            "state": os.path.join(config_dir, target_id, tap_id, TransferFileName.STATE_FILENAME),
            "properties": os.path.join(config_dir, target_id, tap_id, TransferFileName.PROPERTIES_FILENAME),
            "selection": os.path.join(config_dir, target_id, tap_id, TransferFileName.SELECTION_FILENAME),
            "transformation": os.path.join(config_dir, target_id, tap_id, TransferFileName.TRANSFORMATION_FILENAME),
        }
        return mapping

    @staticmethod
    def generate_filename_mapping_field(tap_id, target_id, config_dir):
        inv_mapping = BaseUtils.generate_field_mapping_filename(tap_id, target_id, config_dir)
        mapping = {}
        for key in inv_mapping.keys():
            mapping[inv_mapping[key]] = key
        return mapping

    @staticmethod
    def generate_dict_to_yaml(data, des):
        dirname = os.path.dirname(des)
        if not os.path.exists(dirname):
            os.makedirs(dirname)
        try:
            with open(des, "w") as _f:
                yaml.dump(data, _f)
                return des
        except Exception:
            raise Exception(f'{"generate_dict_to_yml fail"}')

    @staticmethod
    def generate_dict_to_json(data, des):
        try:
            with open(des, "w") as f:
                json.dump(data, f)
                return des
        except Exception:
            raise Exception(f'{"generate_dict_to_dict fail"}')
