"""
PipelineWise CLI
"""
import copy
import errno
import logging
import os
import sys
from cProfile import Profile
from datetime import datetime
from typing import Optional, Tuple

import argparse
from pipelinewise.cli.pipelinewise import PipelineWise
from pipelinewise.cli.utils import generate_random_string
from pipelinewise.logger import Logger
from pkg_resources import get_distribution

__version__ = get_distribution("pipelinewise").version

COMMANDS = [
    "init",
    "run_tap",
    "stop_tap",
    "discover_tap",
    "status",
    "test_tap_connection",
    "sync_tables",
    "import",
    "import_config",
    "validate",
    "encrypt_string",
]


def __init_logger(log_file=None, debug=False):
    """
    Initialise logger and update its handlers and level accordingly
    """
    # get logger for pipelinewise
    logger = Logger(debug).get_logger("pipelinewise")

    # copy log configuration: level and formatter
    level = logger.level
    formatter = copy.deepcopy(logger.handlers[0].formatter)

    # Create log file handler if required
    if log_file and log_file != "*":
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)

        logger.addHandler(file_handler)

    return logger


def __init_profiler(PROFILING_DIR, profiler_arg: bool, logger: logging.Logger) \
        -> Tuple[Optional[Profile], Optional[str]]:
    if profiler_arg:
        logger.info("Profiling mode enabled")

        logger.debug("Creating & enabling profiler ...")

        profiler = Profile()
        profiler.enable()

        logger.debug("Profiler created.")

        profiling_dir = os.path.join(
            PROFILING_DIR,
            f'{datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")}_{generate_random_string(10)}'
        )

        try:
            os.makedirs(profiling_dir)
            logger.debug('Profiling directory "%s" created', profiling_dir)

        except OSError as ex:
            if ex.errno != errno.EEXIST:
                raise

            logger.debug('Profiling directory "%s" already exists', profiling_dir)

        return profiler, profiling_dir

    logger.info("Profiling mode not enabled")

    return None, None


def __disable_profiler(
        profiler: Optional[Profile],
        profiling_dir: Optional[str],
        pstat_filename: Optional[str],
        logger: logging.Logger,
):
    if profiler is not None:
        logger.debug("disabling profiler and dumping stats...")

        profiler.disable()

        if not pstat_filename.endswith(".pstat"):
            pstat_filename = f"{pstat_filename}.pstat"

        dump_file = os.path.join(profiling_dir, pstat_filename)

        logger.debug('Attempting to dump profiling stats in file "%s" ...', dump_file)
        profiler.dump_stats(dump_file)
        logger.debug("Profiling stats dump successful")

        logger.info('Profiling stats files are in folder "%s"', profiling_dir)

        profiler.clear()


# pylint: disable=too-many-branches,too-many-statements
def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="PipelineWise {} - Command Line Interface".format(__version__),
        add_help=True,
    )
    parser.add_argument("command", type=str, choices=COMMANDS)
    parser.add_argument("--target", type=str, default="*", help='"Name of the target')
    parser.add_argument("--tap", type=str, default="*", help="Name of the tap")
    parser.add_argument("--tables", type=str, help="List of tables to sync")
    parser.add_argument("--dir", type=str, default="*", help="Path to directory with config")
    parser.add_argument("--config_dir", type=str, default=False, required=True, help="Path to directory with config", )
    parser.add_argument("--name", type=str, default="*", help="Name of the project")
    parser.add_argument("--secret", type=str, help="Path to vault password file")
    parser.add_argument("--string", type=str)
    parser.add_argument(
        "--version",
        action="version",
        help="Displays the installed versions",
        version="PipelineWise {}" " - " "Command Line Interface".format(__version__),
    )
    parser.add_argument("--log", type=str, default="*", help="File to log into")
    parser.add_argument(
        "--extra_log",
        default=False,
        required=False,
        help="Copy singer and fastsync " "logging into PipelineWise logger",
        action="store_true",
    )
    parser.add_argument(
        "--debug",
        default=False,
        required=False,
        help="Forces the debug mode with logging " "on stdout and log level debug",
        action="store_true",
    )

    parser.add_argument(
        "--profiler",
        "-p",
        default=False,
        required=False,
        help="Enables code profiling mode using Python builtin profiler cProfile. "
             "The stats will be dumped into a folder in .pipelinewise/profiling",
        action="store_true",
    )

    args = parser.parse_args()

    # Command specific argument validations
    if args.command == "init" and args.name == "*":
        print("You must specify a project name using the argument --name")
        sys.exit(1)

    if args.command in ["discover_tap", "test_tap_connection", "run_tap", "stop_tap"]:
        if args.tap == "*":
            print("You must specify a source name using the argument --tap")
            sys.exit(1)
        if args.target == "*":
            print("You must specify a destination name " "using the argument --target")
            sys.exit(1)

    if args.command == "sync_tables":
        if args.tap == "*":
            print("You must specify a source name using the argument --tap")
            sys.exit(1)
        if args.target == "*":
            print("You must specify a destination name " "using the argument --target")
            sys.exit(1)

    if args.command == "import" or args.command == "import_config":
        if args.dir == "*":
            print(
                "You must specify a directory path with config YAML files using the argument --dir"
            )
            sys.exit(1)

        args.command = "import_project"

    if args.command == "validate" and args.dir == "*":
        print(
            "You must specify a directory path with config YAML files using the argument --dir"
        )
        sys.exit(1)

    if args.command == "encrypt_string":
        if not args.secret:
            print(
                "You must specify a path to a file with vault secret using the argument --secret"
            )
            sys.exit(1)
        if not args.string:
            print("You must specify a string to encrypt " "using the argument --string")
            sys.exit(1)

    _user_home = os.path.expanduser("~")
    _config_dir = args.config_dir
    _profiling_dir = os.path.join(_config_dir, "profiling")
    _pipelinewise_default_home = os.path.join(_user_home, "pipelinewise")
    _pipelinewise_home = os.path.abspath(os.environ.setdefault("PIPELINEWISE_HOME", _pipelinewise_default_home))
    _venv_dir = os.path.join(_pipelinewise_home, ".virtualenvs")
    logger = __init_logger(args.log, args.debug)

    profiler, profiling_dir = __init_profiler(_profiling_dir, args.profiler, logger)

    ppw_instance = PipelineWise(args, _config_dir, _venv_dir, profiling_dir)

    try:
        getattr(ppw_instance, args.command)()
    finally:
        __disable_profiler(profiler, profiling_dir, f"pipelinewise_{args.command}", logger)


if __name__ == "__main__":
    main()
