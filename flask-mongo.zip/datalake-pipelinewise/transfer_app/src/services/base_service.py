class BaseService:
    def __init__(self, dao):
        self.dao = dao

    def insert_record(self, record_data):
        return self.dao.insert_record(record_data)

    def get_record_by_id(self, record_id):
        record = self.dao.get_record_by_id(record_id)
        return record

    def delete_record_by_id(self, record_id):
        record = self.dao.delete_record_by_id(record_id)
        return record

    def update_record_by_id(self, record_id, update_data):
        return self.dao.update_record_by_id(
            record_id=record_id, update_data=update_data
        )

    def get_all_records(self):
        records = self.dao.get_all_records()
        return records

    def count_records(self, keyword, status=None):
        conditions = self._parse_conditions_for_get_records(keyword=keyword, status=status)
        result = self.dao.count_records(conditions=conditions)
        return result

    @classmethod
    def _parse_conditions_for_get_records(cls, keyword, status=None):
        return
