from transfer_app.src.commons.consts.response_consts import ResponseCode
from transfer_app.src.commons.consts.transfer_consts import TransferStatusType
from transfer_app.src.commons.errors.response_exception import ResponseException
from transfer_app.src.commons.models.responses.api_error import ApiError
from transfer_app.src.daos.tap_dao import DAOTap
from transfer_app.src.daos.target_dao import DAOTarget
from transfer_app.src.daos.transfer_dao import DAOELT, DAOHistory
from transfer_app.src.transfer_utils.transfer_utils import TransferUtils
from transfer_app.src.transfer_utils.update_history_utils import UpdateHistoryUtils
from transfer_app.src.utils.data_utils import DataUtils
from transfer_app.src.utils.mongo_utils import MongoUtils


class ServiceTransfer:
    def __init__(self):
        self.dao_tap = DAOTap()
        self.dao_target = DAOTarget()
        self.dao_elt = DAOELT()
        self.dao_history = DAOHistory()

    def is_locked(self, record, lock_field, lock_status):
        return getattr(record, lock_field) == lock_status

    def lock_elt(self, elt_id, insert_history_data):
        inserted_history = self.dao_history.insert_record(insert_history_data)
        update_elt_data = {
            "eltStatus": TransferStatusType.RUNNING,
            "lastHistory": DataUtils.mongo_schema_to_dict(inserted_history),
        }
        self.dao_elt.update_record_by_id(elt_id, update_elt_data)
        return

    def validate_status_elt_id(self, elt_id):
        elt_record = self.dao_elt.get_record_by_id(elt_id)
        elt_dict = DataUtils.mongo_schema_to_dict(elt_record)
        if not elt_record:
            errors = [ApiError(code=ResponseCode.NOT_FOUND, message="ELT id not found.")]
            raise ResponseException(http_code=ResponseCode.FAILED_DEPENDENCY, errors=errors)
        if self.is_locked(elt_record, "eltStatus", TransferStatusType.RUNNING):
            errors = [ApiError(code=ResponseCode.SERVICE_UNAVAILABLE, message="ELT id is running")]
            raise ResponseException(http_code=ResponseCode.SERVICE_UNAVAILABLE, errors=errors)

        tap_record = self.dao_tap.get_record_by_id(MongoUtils.string_to_object_id(elt_dict["tapId"]))
        target_record = self.dao_target.get_record_by_id(MongoUtils.string_to_object_id(elt_dict["targetId"]))
        if not tap_record:
            errors = [ApiError(code=ResponseCode.FAILED_DEPENDENCY, message="Tap id not found.")]
            raise ResponseException(http_code=ResponseCode.FAILED_DEPENDENCY, errors=errors)
        if not target_record:
            errors = [ApiError(code=ResponseCode.FAILED_DEPENDENCY, message="Target id not found.")]
            raise ResponseException(http_code=ResponseCode.FAILED_DEPENDENCY, errors=errors)

        return elt_record, tap_record, target_record

    def create_elt(self, tap_id, target_id):
        job_id = tap_id + "_" + target_id
        if not self.dao_tap.get_record_by_id(MongoUtils.string_to_object_id(tap_id)):
            errors = [ApiError(code=ResponseCode.FAILED_DEPENDENCY, message=f"Tap id {tap_id} not found.")]
            raise ResponseException(http_code=ResponseCode.FAILED_DEPENDENCY, errors=errors)
        if not self.dao_target.get_record_by_id(MongoUtils.string_to_object_id(target_id)):
            errors = [ApiError(code=ResponseCode.FAILED_DEPENDENCY, message=f"Target id {target_id} not found.")]
            raise ResponseException(http_code=ResponseCode.FAILED_DEPENDENCY, errors=errors)
        if self.dao_elt.get_record_by_job_id(job_id):
            errors = [
                ApiError(
                    code=ResponseCode.BAD_REQUEST,
                    message=f"ELT for tap {tap_id} - target {target_id} already exists."
                )
            ]
            raise ResponseException(http_code=ResponseCode.BAD_REQUEST, errors=errors)

        record_data = {"tapId": tap_id, "targetId": target_id, "jobId": job_id}
        inserted_record = self.dao_elt.insert_record(record_data)
        return inserted_record

    def import_project(self, elt_id):
        # collect and validate record
        elt_record, tap_record, target_record = self.validate_status_elt_id(elt_id)

        # insert history command and lock elt
        insert_history_data = {
            "eltId": str(elt_record.id),
            "action": "Import project",
            "eltStatus": TransferStatusType.RUNNING,
        }
        self.lock_elt(elt_id, insert_history_data)

        # call import
        try:
            TransferUtils.import_project_from_record(tap_record, target_record, elt_record)
        except Exception as e:
            log_message = str(e)
            update_history_data = {
                "action": "Run",
                "eltStatus": TransferStatusType.STOPPED,
                "retCode": 1,
                "logMessage": log_message,
            }
            UpdateHistoryUtils.update_elt_history(elt_id, update_history_data, self.dao_elt, self.dao_history)
            errors = [ApiError(code=ResponseCode.INTERNAL_SERVER_ERROR, message=str(e))]
            raise ResponseException(http_code=ResponseCode.INTERNAL_SERVER_ERROR, errors=errors)

    def run_tap(self, elt_id):
        # collect record
        elt_record, tap_record, target_record = self.validate_status_elt_id(elt_id)

        # insert history command and lock elt
        insert_history_data = {
            "eltId": elt_id,
            "action": "Run",
            "eltStatus": TransferStatusType.RUNNING,
        }
        self.lock_elt(elt_id, insert_history_data)
        # call transfer
        try:
            TransferUtils.run_elt_from_record(elt_record)
        except ResponseException as error:
            log_message = str(error.errors[-1].message)
            update_history_data = {
                "action": "Run",
                "eltStatus": TransferStatusType.STOPPED,
                "retCode": 1,
                "logMessage": log_message,
            }
            UpdateHistoryUtils.update_elt_history(elt_id, update_history_data, self.dao_elt, self.dao_history)
            raise error

    def reset_state(self, elt_id):
        elt_record = self.dao_elt.get_record_by_id(elt_id)
        if not elt_record:
            errors = [ApiError(code=ResponseCode.NOT_FOUND, message="ELT id not found.")]
            raise ResponseException(http_code=ResponseCode.NOT_FOUND, errors=errors)
        update_data = {
            "state": {},
            "lastHistory": {},
            "eltStatus": TransferStatusType.STOPPED,
        }
        updated_record = self.dao_elt.update_record_by_id(elt_record.id, update_data)
        return updated_record

    def is_last_task_success(self, elt_id):
        elt_record = self.dao_elt.get_record_by_id(elt_id)
        elt_dict = DataUtils.mongo_schema_to_dict(elt_record)
        if not elt_record:
            errors = [ApiError(code=ResponseCode.NOT_FOUND, message="ELT id not found.")]
            raise ResponseException(http_code=ResponseCode.NOT_FOUND, errors=errors)
        if elt_dict["lastHistory"] is None or elt_dict["lastHistory"] == {}:
            errors = [ApiError(code=ResponseCode.NOT_FOUND, message="No task is requested for this elt.")]
            raise ResponseException(http_code=ResponseCode.BAD_REQUEST, errors=errors)
        # Check locked
        if self.is_locked(elt_record, "eltStatus", TransferStatusType.RUNNING):
            errors = [ApiError(code=ResponseCode.FAILED_DEPENDENCY, message="ELT is running.")]
            raise ResponseException(http_code=ResponseCode.FAILED_DEPENDENCY, errors=errors)
        elt_dict = DataUtils.mongo_schema_to_dict(elt_record)
        elt_last_history = elt_dict["lastHistory"]
        if int(elt_last_history["retCode"]) == 0:
            return True, elt_last_history
        else:
            return False, elt_last_history
