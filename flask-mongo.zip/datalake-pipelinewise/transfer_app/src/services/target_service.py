from transfer_app.src.daos.target_dao import DAOTarget

from .base_service import BaseService


class ServiceTarget(BaseService):
    def __init__(self):
        super().__init__(DAOTarget())

    def _normalize_record_to_description(self, record):
        return {"_id": record.id, "description": record.description}

    def get_all_descriptions(self):
        records = self.get_all_records()
        descriptions = []
        for record in records:
            descriptions.append(self._normalize_record_to_description(record))
        return descriptions

    def get_desciption_by_id(self, record_id):
        record = self.get_record_by_id(record_id)
        description = self._normalize_record_to_description(record)
        return description
