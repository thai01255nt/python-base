from transfer_app.src.daos.transfer_dao import DAOELT, DAOHistory
from transfer_app.src.utils.data_utils import DataUtils

from .base_service import BaseService


class ServiceELT(BaseService):
    def __init__(self):
        super().__init__(DAOELT())

    def get_record_by_job_id(self, job_id):
        return self.dao.get_record_by_job_id(job_id)

    def get_status_by_id(self):
        pass


class ServiceHistory(BaseService):
    def __init__(self):
        super().__init__(DAOHistory())

    def get_records_by_elt_id(self, elt_id):
        return self.dao.get_records_by_elt_id(elt_id)
    
    def get_reports_history_by_date(self, date):
        try:
            documents = self.dao.get_records_by_time(date)
        except Exception as e: # DEBUG CODE
            print('ERROR LOG: ' + str(e))
            return None
        
        total_docs, condition_docs = DataUtils.count_condition_docs(documents, {'action': 'Run'}, retCode=0)
        success = error = 0
        if total_docs != 0:
            success = round(100*condition_docs/total_docs,3)
            error = round(100 - 100*condition_docs/total_docs,3) 

        reports = {
            'success': success,
            'error': error,
            'total_actions': total_docs
        }
        return reports
