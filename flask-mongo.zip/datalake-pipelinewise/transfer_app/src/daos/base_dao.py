class DAOBase:
    def __init__(self, schema):
        self.schema = schema

    def insert_record(self, record_data):
        record = self.schema(**record_data)
        inserted_record = record.save()
        return inserted_record

    def delete_record_by_id(self, record_id):
        record = self.get_record_by_id(record_id)
        record.delete()
        return record

    def update_record_by_id(self, record_id, update_data):
        record = self.get_record_by_id(record_id=record_id)
        for update_field in update_data.keys():
            setattr(record, update_field, update_data[update_field])
        record = record.save()
        return record

    def get_record_by_id(self, record_id):
        record = self.schema.objects(id=record_id).first()
        return record

    def get_all_records(self):
        records = self.schema.objects({})
        return records
