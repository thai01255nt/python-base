from transfer_app.src.schemas.elt_schema import SchemaELT
from transfer_app.src.schemas.history_schema import SchemaHistory
import dateutil.parser
from datetime import timedelta

from .base_dao import DAOBase


class DAOELT(DAOBase):
    def __init__(self):
        super().__init__(SchemaELT)

    def get_record_by_job_id(self, job_id):
        record = self.schema.objects(jobId=job_id).first()
        return record


class DAOHistory(DAOBase):
    def __init__(self):
        super().__init__(SchemaHistory)

    def get_records_by_elt_id(self, elt_id):
        records = self.schema.objects(eltId=elt_id).order_by("createdAt")
        return records

    def get_records_by_time(self, time_range):
        start_date = dateutil.parser.isoparse(time_range[0])
        end_date = dateutil.parser.isoparse(time_range[1])
        
        records = self.schema.objects(createdAt__gte = start_date, createdAt__lte= end_date)
        return records.order_by("createdAt")
