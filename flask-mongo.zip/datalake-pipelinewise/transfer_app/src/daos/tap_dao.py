from transfer_app.src.schemas.tap_schema import SchemaTap

from .base_dao import DAOBase


class DAOTap(DAOBase):
    def __init__(self):
        super().__init__(SchemaTap)
