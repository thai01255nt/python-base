from transfer_app.src.schemas.target_schema import SchemaTarget

from .base_dao import DAOBase


class DAOTarget(DAOBase):
    def __init__(self):
        super().__init__(SchemaTarget)
