class TransferFileName:
    GLOBAL_CONFIG_FILENAME = "config.json"
    TAP_CONFIG_FILENAME = "config.json"
    TARGET_CONFIG_FILENAME = "config.json"
    INHERITABLE_CONFIG_FILENAME = "inheritable_config.json"
    STATE_FILENAME = "state.json"
    PROPERTIES_FILENAME = "properties.json"
    SELECTION_FILENAME = "selection.json"
    TRANSFORMATION_FILENAME = "transformation.json"
    TAP_YAML_FILENAME = "tap_setel.yaml"
    TARGET_YAML_FILENAME = "target_setel.yaml"
    YAML_FOLDER = "yaml/"


class TransferStatusType:
    STOPPED = "STOPPED"
    RUNNING = "RUNNING"
