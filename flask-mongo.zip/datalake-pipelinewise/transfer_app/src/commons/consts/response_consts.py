class ErrorMessage:
    # VALIDATION_FAILED = "Validation failed"
    # UNAUTHORIZED = "Unauthorized"
    # FORBIDDEN = "Forbidden"
    BAD_REQUEST = "Bad request"
    NOT_FOUND = "Not found"
    CONFLICT = "Conflict"
    REQUEST_FAIL = "Request fail"


class LocationType:
    BODY = "body"
    QUERY = "query"


class ResponseCode:
    OK = 200
    CREATED = 201
    ACCEPTED = 202
    NO_CONTENT = 204
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    REQUEST_FAIL = 402
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    CONFLICT = 409
    LOCKED = 423
    FAILED_DEPENDENCY = 424
    INTERNAL_SERVER_ERROR = 500
    SERVICE_UNAVAILABLE = 503


class ResponseBodyCode:
    COMMON = {"OK": "ok"}
    TAP = {
        "TAP_ID_NOT_FOUND": "tapIdNotFound",
    }
    TARGET = {
        "TARGET_ID_NOT_FOUND": "targetIdNotFound",
    }
    ELT = {
        "JOB_ID_ALREADY_EXISTS": "jobIdAlreadyExists",
        "JOB_ID_NOT_FOUND": "jobIdNotFound",
        "JOB_ID_IS_RUNNING": "jobIdIsRunning",
        "UNK": "internalServerError",
    }
