class FieldType:
    DICT = "dict"
    STRING = "string"
    NUMBER = "number"
    OID = "oid"
    SELECT = "select"
    LIST = "list"
    BOOL = "bool"


class DbAliasType:
    TRANSFER_DB_ALIAS = "transfer-db-alias"
