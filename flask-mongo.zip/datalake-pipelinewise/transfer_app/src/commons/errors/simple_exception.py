class SimpleException(Exception):
    def __init__(self, errors):
        self.errors = errors  # list of ApiError
