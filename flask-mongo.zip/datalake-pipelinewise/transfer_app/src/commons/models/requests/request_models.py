from transfer_app.src.commons.consts.database_consts import FieldType
from .document_field import DocumentField

REQUEST_MODELS_TAP = {
    "config": DocumentField(field_type=FieldType.DICT, required=True, editable=True),
    "description": DocumentField(field_type=FieldType.STRING, required=False, editable=True),
}

REQUEST_MODELS_TARGET = {
    "config": DocumentField(field_type=FieldType.DICT, required=True, editable=True),
    "description": DocumentField(field_type=FieldType.STRING, required=False, editable=True),
}

REQUEST_MODELS_ELT_CREATE = {
    "tapId": DocumentField(field_type=FieldType.STRING, required=True, editable=True),
    "targetId": DocumentField(field_type=FieldType.STRING, required=True, editable=True),
}

REQUEST_MODELS_ELT_IMPORT = {}
REQUEST_MODELS_ELT_RUN = {}
REQUEST_MODELS_ELT_RESET = {}
