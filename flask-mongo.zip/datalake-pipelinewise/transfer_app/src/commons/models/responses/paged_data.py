class PagedData:
    def __init__(self, items, total_count, offset):
        if items and len(items) > 0:
            self.items = items
            self._prev_offset = offset - 1 if offset else None
            if self._prev_offset is None:
                self._next_offset = len(items) if total_count > len(items) else None
            else:
                self._next_offset = (
                    self._prev_offset + len(items) + 1
                    if total_count > len(items) + 1
                    else None
                )
            self._total_count = total_count
        else:
            self.items = []
            self._prev_offset = None
            self._next_offset = None
            self._total_count = None

    def to_dict(self):
        result = {
            "_prev_offset": self._prev_offset,
            "_next_offset": self._next_offset,
            "_total_count": self._total_count,
            "items": self.items,
        }

        return result
