from mongoengine import Document

from transfer_app.src.commons.models.responses.paged_data import PagedData
from transfer_app.src.utils.data_utils import DataUtils


class BaseResponse:
    def __init__(self, code=None, message=None, data=None, errors=None):
        self.code = code
        self.message = message
        self.data = data
        self.errors = errors

    def to_dict(self):
        result = {}
        if DataUtils.is_has_value(self.code):
            result["code"] = self.code
        if DataUtils.is_has_value(self.message):
            result["message"] = self.message
        if DataUtils.is_has_value(self.data):
            data = self.data
            if issubclass(data.__class__, Document):
                data = DataUtils.mongo_schema_to_dict(data)
            elif isinstance(data, PagedData):
                data = data.to_dict()
            elif isinstance(data, dict):
                data = DataUtils.mongo_dict_to_dict(data)
            result["data"] = data
        if self.errors:
            result["errors"] = [error.__dict__ for error in self.errors]
        return result
