import datetime

from transfer_app.src.utils.security_utils import CryptoUtil

from mongoengine import (
    Document,
    DictField,
    StringField,
    DateTimeField
)
from transfer_app.src.commons.consts.database_consts import DbAliasType


class SchemaTap(Document):
    config = DictField(required=True, db_field="config")
    description = StringField(db_field="description")

    createdAt = DateTimeField(db_field="createdAt")
    updatedAt = DateTimeField(db_field="updatedAt")
    meta = {"db_alias": DbAliasType.TRANSFER_DB_ALIAS, "collection": "taps"}

    def save(self, *args, **kwargs):
        if not self.createdAt:
            self.createdAt = datetime.datetime.utcnow()
        self.updatedAt = datetime.datetime.utcnow()

        # security encrypt
        if self.config:
            if 'encrypted_config' not in self.config.keys():
                self.config = {
                    'encrypted_config': CryptoUtil.encrypt_json_to_string(self.config)
                }

        return super().save(*args, **kwargs)
    
    @staticmethod
    def decrypt(string:str):
        return CryptoUtil.decrypt_string_to_json(string)
