import datetime

from transfer_app.src.utils.security_utils import CryptoUtil

from mongoengine import (
    Document,
    StringField,
    DictField,
    DateTimeField
)

from transfer_app.src.commons.consts.database_consts import DbAliasType
from transfer_app.src.commons.consts.transfer_consts import TransferStatusType


class SchemaELT(Document):
    tapId = StringField(required=True, db_field="tapId")
    targetId = StringField(required=True, db_field="targetId")
    jobId = StringField(required=True, db_field="jobId")

    globalConfig = DictField(db_field="globalConfig")
    tapConfig = DictField(db_field="tapConfig")
    targetConfig = DictField(db_field="targetConfig")

    inheritableConfig = DictField(db_field="inheritableConfig")
    state = DictField(db_field="state")
    properties = DictField(db_field="properties")
    selection = DictField(db_field="selection")
    transformation = DictField(db_field="transformation")

    eltStatus = StringField(db_field="eltStatus")
    lastHistory = DictField(db_field="lastHistory")
    description = StringField(db_field="description")

    createdAt = DateTimeField(db_field="createdAt")
    updatedAt = DateTimeField(db_field="updatedAt")
    meta = {"db_alias": DbAliasType.TRANSFER_DB_ALIAS, "collection": "elts"}

    def save(self, *args, **kwargs):
        if not self.createdAt:
            self.eltStatus = TransferStatusType.STOPPED
            self.createdAt = datetime.datetime.utcnow()
        self.updatedAt = datetime.datetime.utcnow()

        # security encrypt
        if self.tapConfig:
            if 'encrypted_config' not in self.tapConfig:
                self.tapConfig = {
                    'encrypted_config': CryptoUtil.encrypt_json_to_string(self.tapConfig)
                }

        if self.targetConfig:
            if 'encrypted_config' not in self.targetConfig:
                self.targetConfig = {
                    'encrypted_config': CryptoUtil.encrypt_json_to_string(self.targetConfig)
                }

        return super().save(*args, **kwargs)

    @staticmethod
    def decrypt(string:str):
        return CryptoUtil.decrypt_string_to_json(string)
