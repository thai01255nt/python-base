import datetime

from mongoengine import (
    Document,
    StringField,
    IntField,
    DateTimeField
)

from transfer_app.src.commons.consts.database_consts import DbAliasType
from transfer_app.src.commons.consts.transfer_consts import TransferStatusType


class SchemaHistory(Document):
    eltId = StringField(required=True, db_field="eltId")

    action = StringField(required=True, db_field="action")
    duration = StringField(db_field="duration")
    eltStatus = StringField(db_field="eltStatus")
    retCode = IntField(db_field="retCode")
    logMessage = StringField(db_field="logMessage")

    createdAt = DateTimeField(db_field="createdAt")
    updatedAt = DateTimeField(db_field="updatedAt")
    meta = {"db_alias": DbAliasType.TRANSFER_DB_ALIAS, "collection": "histories"}

    def save(self, *args, **kwargs):
        if not self.createdAt:
            self.eltStatus = TransferStatusType.RUNNING
            self.createdAt = datetime.datetime.utcnow()
        self.updatedAt = datetime.datetime.utcnow()
        return super().save(*args, **kwargs)
