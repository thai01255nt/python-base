import os

from flask import Flask
from flask_cors import CORS
from flask_restx import Api
from mongoengine import connect

from transfer_app.src.commons.consts.database_consts import DbAliasType
from transfer_app.src.commons.errors.response_exception import ResponseException
from transfer_app.src.controllers.elt_history_controller import (
    ControllerELTCreate,
    ControllerELTDetail,
    ControllerELTList,
)
from transfer_app.src.controllers.elt_history_controller import (
    ControllerHistoryList,
    ControllerHistoryReport,
)
from transfer_app.src.controllers.tap_controller import (
    ControllerTapCreate,
    ControllerTapDetail,
    ControllerTapDescriptions,
    ControllerTapList,
)
from transfer_app.src.controllers.target_controller import (
    ControllerTargetDetail,
    ControllerTargetCreate,
    ControllerTargetList,
    ControllerTargetDescriptions,
)
from transfer_app.src.controllers.transfer_controller import (
    ControllerELTRun,
    ControllerELTImport,
    ControllerELTReset,
    ControllerELTIsNotLocked,
    ControllerELTIsLastTaskSuccess,
)
from transfer_app.src.utils.config_utils import get_system_config
from transfer_app.src.utils.mongo_utils import MongoUtils
from transfer_app.src.utils.response_utils import ResponseUtils

app = Flask(__name__)
CORS(app)
env = os.getenv("FLASK_ENV")
config_data = get_system_config(env)
app.config["SYS"] = config_data

config_db = config_data.get("db")

# DB_URI = MongoUtils.generate_uri(config_db)
# db = connect(host=DB_URI,alias='transfer-db-alias')

connection_params_db = MongoUtils.generate_params_connection(config_db)
db = connect(alias=DbAliasType.TRANSFER_DB_ALIAS, **connection_params_db)

app.db = db

api = Api(app, prefix="/api.dev.setel.my/transfers/v1")


@api.errorhandler(ResponseException)
def handle_custom_exception(exception):
    return ResponseUtils.parse_response_from_response_exception(exception)


api.add_resource(ControllerTapCreate, "/taps")
api.add_resource(ControllerTapDetail, "/taps/<string:record_id>")
api.add_resource(ControllerTapList, "/taps")
api.add_resource(ControllerTapDescriptions, "/taps/descriptions")

api.add_resource(ControllerTargetCreate, "/targets")
api.add_resource(ControllerTargetDetail, "/targets/<string:record_id>")
api.add_resource(ControllerTargetList, "/targets")
api.add_resource(ControllerTargetDescriptions, "/targets/descriptions")

api.add_resource(ControllerELTCreate, "/elts")
api.add_resource(ControllerELTDetail, "/elts/<string:record_id>")
api.add_resource(ControllerELTList, "/elts")

api.add_resource(ControllerELTImport, "/elts/<string:record_id>/import")
api.add_resource(ControllerELTRun, "/elts/<string:record_id>/run")
api.add_resource(ControllerELTReset, "/elts/<string:record_id>/reset")
api.add_resource(ControllerELTIsNotLocked, "/elts/<string:record_id>/is-not-locked")
api.add_resource(ControllerELTIsLastTaskSuccess, "/elts/<string:record_id>/is-last-task-success")
api.add_resource(ControllerHistoryList, "/histories/elts/<string:elt_id>")
api.add_resource(ControllerHistoryReport, "/histories/reports")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
