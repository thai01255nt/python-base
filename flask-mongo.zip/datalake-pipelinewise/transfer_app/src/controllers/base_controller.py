from flask import request
from flask_restx import Resource

from transfer_app.src.commons.consts.response_consts import ResponseCode, ErrorMessage
from transfer_app.src.commons.errors.response_exception import ResponseException
from transfer_app.src.commons.errors.simple_exception import SimpleException
from transfer_app.src.middlewares.permission_middleware import valid_object_id_required
from transfer_app.src.utils.data_utils import DataUtils
from transfer_app.src.utils.mongo_utils import MongoUtils
from transfer_app.src.utils.request_model_utils import RequestModelUtils


class ControllerBase(Resource):
    def __init__(self, service, request_model):
        self.service = service
        self.request_model = request_model

    @classmethod
    def _handle_exception(cls, exception):
        return _handle_exception(exception)


class ControllerBaseGet(ControllerBase):
    @valid_object_id_required
    def get(self, record_id):
        mongo_object_id = MongoUtils.string_to_object_id(record_id)
        record = self.service.get_record_by_id(mongo_object_id)
        if not record:
            return {"message": "Not found!"}, ResponseCode.NOT_FOUND
        response_body = DataUtils.mongo_schema_to_dict(record)
        return response_body, ResponseCode.OK


class ControllerBasePost(ControllerBase):
    def post(self):
        request_body = request.get_json()
        try:
            request_data = self._parse_data_for_post(request_body)
            data = self.service.insert_record(request_data)
            response_body = DataUtils.mongo_schema_to_dict(data)
            return response_body, ResponseCode.CREATED
        except Exception as exception:
            return self._handle_exception(exception)

    def _parse_data_for_post(self, data):
        return RequestModelUtils.parse_data_for_insert(request_model=self.request_model, data=data)


class ControllerBaseDelete(ControllerBase):
    @valid_object_id_required
    def delete(self, record_id):
        try:
            mongo_object_id = MongoUtils.string_to_object_id(record_id)
        except Exception as exception:
            return str(exception), ResponseCode.BAD_REQUEST
        record = self.service.get_record_by_id(mongo_object_id)
        if not record:
            return {"message": "Not found!"}, ResponseCode.NOT_FOUND
        deleted_record = self.service.delete_record_by_id(mongo_object_id)
        response_body = DataUtils.mongo_schema_to_dict(deleted_record)
        return response_body, ResponseCode.OK


class ControllerBasePatch(ControllerBase):
    @valid_object_id_required
    def patch(self, record_id):
        request_body = request.get_json()
        try:
            del request_body["_id"]
        except Exception:
            pass
        try:
            mongo_object_id = MongoUtils.string_to_object_id(record_id)
        except Exception as exception:
            return str(exception), ResponseCode.BAD_REQUEST
        record = self.service.get_record_by_id(mongo_object_id)
        if not record:
            return {"message": "Not found!"}, ResponseCode.NOT_FOUND
        try:
            update_data = self._parse_data_for_patch(request_body)
            if len(update_data.keys()) > 0:
                updated_record = self.service.update_record_by_id(record_id=record_id, update_data=update_data)
                response_body = DataUtils.mongo_schema_to_dict(updated_record)
                return response_body, ResponseCode.OK
            return "", ResponseCode.NO_CONTENT

        except Exception as exception:
            return self._handle_exception(exception)

    def _parse_data_for_patch(self, data):
        return RequestModelUtils.parse_data_for_update(request_model=self.request_model, data=data)


class ControllerBaseGetAll(ControllerBase):
    def get(self):
        records = self.service.get_all_records()
        response_body = []
        for record in records:
            response_body.append(DataUtils.mongo_schema_to_dict(record))
        return response_body, ResponseCode.OK


def _handle_exception(exception):
    if isinstance(exception, SimpleException):
        errors = exception.errors
        exception = ResponseException(
            http_code=ResponseCode.BAD_REQUEST,
            message=ErrorMessage.BAD_REQUEST,
            errors=errors,
        )
        return {"message": exception.errors[-1].message}, exception.http_code
    if isinstance(exception, ResponseException):
        return {"message": exception.errors[-1].message}, exception.http_code
    exception = ResponseException(http_code=ResponseCode.INTERNAL_SERVER_ERROR)
    return {"message": "Unkown error!"}, exception.http_code


class ControllerBaseELTPatch(ControllerBasePatch):
    def __init__(self, service_transfer, service_elt, request_model):
        self.service_transfer = service_transfer
        self.service_elt = service_elt
        self.request_model = request_model
