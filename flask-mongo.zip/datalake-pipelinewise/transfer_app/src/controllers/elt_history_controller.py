from flask import request

from transfer_app.src.commons.consts.response_consts import ResponseCode
from transfer_app.src.commons.models.requests.request_models import (
    REQUEST_MODELS_ELT_CREATE,
)
from transfer_app.src.services.elt_history_service import ServiceELT, ServiceHistory
from transfer_app.src.services.transfer_service import ServiceTransfer
from transfer_app.src.utils.data_utils import DataUtils
from .base_controller import (
    ControllerBasePost,
    ControllerBaseGet,
    ControllerBaseDelete,
    ControllerBaseGetAll,
    ControllerBasePatch,
)


class ControllerELTCreate(ControllerBasePost):
    def __init__(self, *kwargs):
        super().__init__(ServiceTransfer(), REQUEST_MODELS_ELT_CREATE)

    def post(self):
        request_body = request.get_json()
        try:
            request_data = self._parse_data_for_post(request_body)
            tap_id = request_data["tapId"]
            target_id = request_data["targetId"]
            inserted_data = self.service.create_elt(tap_id, target_id)
            response_body = DataUtils.mongo_schema_to_dict(inserted_data)
            return response_body, ResponseCode.CREATED
        except Exception as exception:
            return self._handle_exception(exception)


class ControllerELTDetail(ControllerBaseGet, ControllerBaseDelete, ControllerBasePatch):
    def __init__(self, *kwargs):
        service = ServiceELT()
        ControllerBaseGet.__init__(self, service, {})
        ControllerBaseDelete.__init__(self, service, {})


class ControllerELTList(ControllerBaseGetAll):
    def __init__(self, *kwargs):
        super().__init__(ServiceELT(), {})


class ControllerHistoryList(ControllerBaseGetAll):
    def __init__(self, *kwargs):
        super().__init__(ServiceHistory(), {})

    def get(self, elt_id):
        records = self.service.get_records_by_elt_id(elt_id)
        response_body = []
        for record in records:
            response_body.append(DataUtils.mongo_schema_to_dict(record))
        return response_body, ResponseCode.OK


class ControllerHistoryReport(ControllerBasePost):
    def __init__(self, *kwargs):
        super().__init__(ServiceHistory(), {})
    
    def post(self):
        request_body = request.get_json()
        try:
            request_data = self._parse_data_for_post(request_body)
            date = [request_body['from_date'], request_body['to_date']]
            # return result
            response_body = self.service.get_reports_history_by_date(date)
            return response_body, ResponseCode.OK
        except Exception as exception:
            return self._handle_exception(exception)
