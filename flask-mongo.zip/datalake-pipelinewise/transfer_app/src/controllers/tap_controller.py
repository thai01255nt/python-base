from transfer_app.src.commons.consts.response_consts import ResponseCode
from transfer_app.src.commons.models.requests.request_models import REQUEST_MODELS_TAP
from transfer_app.src.services.tap_service import ServiceTap
from transfer_app.src.utils.data_utils import DataUtils
from .base_controller import (
    ControllerBasePost,
    ControllerBaseGet,
    ControllerBaseDelete,
    ControllerBaseGetAll,
)


class ControllerTapCreate(ControllerBasePost):
    def __init__(self, *kwargs):
        super().__init__(ServiceTap(), REQUEST_MODELS_TAP)


class ControllerTapDetail(ControllerBaseGet, ControllerBaseDelete):
    def __init__(self, *kwargs):
        service = ServiceTap()
        ControllerBaseGet.__init__(self, service, REQUEST_MODELS_TAP)
        ControllerBaseDelete.__init__(self, service, REQUEST_MODELS_TAP)


class ControllerTapList(ControllerBaseGetAll):
    def __init__(self, *kwargs):
        super().__init__(ServiceTap(), REQUEST_MODELS_TAP)


class ControllerTapDescriptions(ControllerBaseGetAll):
    def __init__(self, *kwargs):
        super().__init__(ServiceTap(), REQUEST_MODELS_TAP)

    def get(self):
        descriptions = self.service.get_all_descriptions()
        response_body = []
        for description in descriptions:
            response_body.append(DataUtils.mongo_dict_to_dict(description))
        return response_body, ResponseCode.OK
