from flask import request

from transfer_app.src.commons.consts.response_consts import ResponseCode
from transfer_app.src.commons.consts.transfer_consts import TransferStatusType
from transfer_app.src.commons.models.requests.request_models import (
    REQUEST_MODELS_ELT_RUN,
    REQUEST_MODELS_ELT_IMPORT,
    REQUEST_MODELS_ELT_RESET,
)
from transfer_app.src.middlewares.permission_middleware import valid_object_id_required
from transfer_app.src.services.elt_history_service import ServiceELT
from transfer_app.src.services.transfer_service import ServiceTransfer
from transfer_app.src.utils.mongo_utils import MongoUtils
from .base_controller import ControllerBaseELTPatch, ControllerBase


class ControllerELTImport(ControllerBaseELTPatch):
    def __init__(self, *kwargs):
        super().__init__(
            service_elt=ServiceELT(),
            service_transfer=ServiceTransfer(),
            request_model=REQUEST_MODELS_ELT_IMPORT,
        )

    @valid_object_id_required
    def patch(self, record_id):
        request_body = request.get_json()
        # validate elt
        self._parse_data_for_patch(request_body)

        try:
            # import elt
            elt_record = self.service_elt.get_record_by_id(record_id)
            if not elt_record:
                return {"message": "ELT not found!"}, ResponseCode.NOT_FOUND
            elt_id = record_id
            self.service_transfer.import_project(elt_id)
            # response
            response_body = {"_id": str(elt_record.id), "message": f"request import elt_id {elt_id} success"}
            return response_body, ResponseCode.OK
        except Exception as exception:
            return self._handle_exception(exception)


class ControllerELTRun(ControllerBaseELTPatch):
    def __init__(self, *kwargs):
        super().__init__(
            service_elt=ServiceELT(),
            service_transfer=ServiceTransfer(),
            request_model=REQUEST_MODELS_ELT_RUN,
        )

    @valid_object_id_required
    def patch(self, record_id):
        request_body = request.get_json()
        self._parse_data_for_patch(request_body)
        # validate elt
        elt_record = self.service_elt.get_record_by_id(record_id)
        if not elt_record:
            return {"message": "Not found elt!"}, ResponseCode.NOT_FOUND
        # run elt
        try:
            elt_id = record_id
            self.service_transfer.run_tap(elt_id)
            # response
            response_body = {
                "_id": str(elt_record.id),
                "message": f"request run elt {elt_id} success",
            }
            return response_body, ResponseCode.OK
        except Exception as exception:
            return self._handle_exception(exception)


class ControllerELTReset(ControllerBaseELTPatch):
    def __init__(self, *kwargs):
        super().__init__(
            service_elt=ServiceELT(),
            service_transfer=ServiceTransfer(),
            request_model=REQUEST_MODELS_ELT_RESET,
        )

    @valid_object_id_required
    def patch(self, record_id):
        request_body = request.get_json()
        self._parse_data_for_patch(request_body)
        # validate elt
        elt_record = self.service_elt.get_record_by_id(record_id)
        if not elt_record:
            return {"message": "Not found elt!"}, ResponseCode.NOT_FOUND
        try:
            elt_id = record_id
            self.service_transfer.reset_state(elt_id)
            # response
            response_body = {
                "_id": str(elt_record.id),
                "message": f"Reset status elt {elt_id} success.",
            }
            return response_body, ResponseCode.OK
        except Exception as exception:
            return self._handle_exception(exception)


class ControllerELTIsNotLocked(ControllerBase):
    def __init__(self, *kwargs):
        self.service_transfer = ServiceTransfer()
        self.service_elt = ServiceELT()

    @valid_object_id_required
    def get(self, record_id):
        mongo_object_id = MongoUtils.string_to_object_id(record_id)
        elt_record = self.service_elt.get_record_by_id(mongo_object_id)
        if not elt_record:
            return {"message": "Not found!"}, ResponseCode.NOT_FOUND
        if self.service_transfer.is_locked(elt_record, "eltStatus", TransferStatusType.RUNNING):
            return {"message": "ELT is running proccess!"}, ResponseCode.SERVICE_UNAVAILABLE
        return {"message": "ELT is available!"}, ResponseCode.OK


class ControllerELTIsLastTaskSuccess(ControllerBase):
    def __init__(self, *kwargs):
        self.service_transfer = ServiceTransfer()
        self.service_elt = ServiceELT()

    @valid_object_id_required
    def get(self, record_id):
        mongo_object_id = MongoUtils.string_to_object_id(record_id)
        elt_record = self.service_elt.get_record_by_id(mongo_object_id)
        if not elt_record:
            return {"message": "Not found!"}, ResponseCode.NOT_FOUND
        is_last_task_success, elt_last_history = self.service_transfer.is_last_task_success(record_id)
        if is_last_task_success:
            elt_last_history["message"] = "Last task is success!"
            return elt_last_history, ResponseCode.OK

        elt_last_history["message"] = "Last task is failed!"
        return elt_last_history, ResponseCode.FAILED_DEPENDENCY
