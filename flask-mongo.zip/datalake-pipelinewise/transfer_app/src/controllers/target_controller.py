from transfer_app.src.commons.consts.response_consts import ResponseCode
from transfer_app.src.commons.models.requests.request_models import (
    REQUEST_MODELS_TARGET,
)
from transfer_app.src.services.target_service import ServiceTarget
from transfer_app.src.utils.data_utils import DataUtils
from .base_controller import (
    ControllerBaseGet,
    ControllerBasePost,
    ControllerBaseDelete,
    ControllerBaseGetAll,
)


class ControllerTargetCreate(ControllerBasePost):
    def __init__(self, *kwargs):
        super().__init__(ServiceTarget(), REQUEST_MODELS_TARGET)


class ControllerTargetDetail(ControllerBaseGet, ControllerBaseDelete):
    def __init__(self, *kwargs):
        service = ServiceTarget()
        ControllerBaseGet.__init__(self, service, REQUEST_MODELS_TARGET)
        ControllerBaseDelete.__init__(self, service, REQUEST_MODELS_TARGET)


class ControllerTargetList(ControllerBaseGetAll):
    def __init__(self, *kwargs):
        super().__init__(ServiceTarget(), REQUEST_MODELS_TARGET)


class ControllerTargetDescriptions(ControllerBaseGetAll):
    def __init__(self, *kwargs):
        super().__init__(ServiceTarget(), REQUEST_MODELS_TARGET)

    def get(self):
        descriptions = self.service.get_all_descriptions()
        response_body = []
        for description in descriptions:
            response_body.append(DataUtils.mongo_dict_to_dict(description))
        return response_body, ResponseCode.OK
