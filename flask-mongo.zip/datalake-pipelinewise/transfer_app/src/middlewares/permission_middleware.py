from functools import wraps

from transfer_app.src.commons.consts.response_consts import ResponseCode, ErrorMessage
from transfer_app.src.commons.errors.response_exception import ResponseException
from transfer_app.src.utils.mongo_utils import MongoUtils


def valid_object_id_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        record_id = list(kwargs.values())[0]
        is_valid_object_id = MongoUtils.is_valid_object_id(record_id)
        if not is_valid_object_id:
            raise ResponseException(http_code=ResponseCode.NOT_FOUND, message=ErrorMessage.NOT_FOUND)
        return f(*args, **kwargs)

    return wrap

# def auth_required(f):
#     @wraps(f)
#     def wrap(*args, **kwargs):
#         user = get_user_info_from_request(request)
#         if not user:
#             raise ResponseException(http_code=ResponseCode.UNAUTHORIZED,
#                                     body_code=ResponseBodyCode.TOKEN_AUTH[
#                                         "INVALID_TOKEN"],
#                                     message="User not found")
#         else:
#             if not user['activated']:
#                 raise ResponseException(http_code=ResponseCode.UNAUTHORIZED,
#                                         body_code=ResponseBodyCode.TOKEN_AUTH[
#                                             "INVALID_TOKEN"],
#                                         message="User inactive")
#         return f(*args, **kwargs)
#
#     return wrap
#
#
# def admin_required(f):
#     @wraps(f)
#     def wrap(*args, **kwargs):
#         if not is_admin(request):
#             raise ResponseException(http_code=ResponseCode.FORBIDDEN,
#                                     message=ErrorMessage.FORBIDDEN)
#         return f(*args, **kwargs)
#
#     return wrap
#
#
# def get_token_payload_from_request(req):
#     headers = req.headers
#     if not headers or not headers.get("x-access-token"):
#         raise ResponseException(http_code=ResponseCode.UNAUTHORIZED,
#                                 body_code=ResponseBodyCode.TOKEN_AUTH[
#                                     "NO_TOKEN"],
#                                 message="No token provided")
#     token = headers.get("x-access-token")
#     try:
#         payload = TokenUtils.decode_token(token)
#         return payload
#     except Exception as e:
#         raise ResponseException(http_code=ResponseCode.UNAUTHORIZED,
#                                 body_code=ResponseBodyCode.TOKEN_AUTH[
#                                     "INVALID_TOKEN"],
#                                 message="Failed to authenticate token")
#
#
# def get_user_info_from_request(req):
#     try:
#         user_service = UserService()
#         payload = get_token_payload_from_request(req)
#         email = payload["email"]  # email ~ id
#         user = user_service.get_user_by_email(email)
#         # g.user_info = DataUtils.mongo_document_to_dict(user)
#         g.user_info = user
#         return user
#     except Exception as e:
#         raise e
#
#
# def is_admin(req):
#     try:
#         user = get_user_info_from_request(req)
#         if not user:
#             raise ResponseException(http_code=ResponseCode.UNAUTHORIZED,
#                                     body_code=ResponseBodyCode.TOKEN_AUTH[
#                                         "INVALID_TOKEN"],
#                                     message="User not found")
#         return user.is_admin()
#     except Exception as e:
#         raise e
